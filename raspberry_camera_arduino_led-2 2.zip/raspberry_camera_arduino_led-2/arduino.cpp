// arduino.cpp
// -----------------------------------------------------------------------
// Ouvre le port série USB vers l'Arduino et lit ses messages JSON
// ("{"capteur":"bouton"}" / "{"capteur":"photoresistance",...}") SANS
// jamais bloquer le programme principal — c'est essentiel puisque la
// caméra doit continuer à capturer des images en continu pendant ce temps.
//
// On utilise directement l'API POSIX bas niveau (termios) plutôt qu'une
// bibliothèque tierce, pour ne pas ajouter de dépendance supplémentaire
// (le port série est une fonctionnalité standard de Linux).
// -----------------------------------------------------------------------

#include "arduino.h"
#include <iostream>
#include <cstring>
#include <cerrno>       // pour errno / strerror : savoir POURQUOI l'ouverture a échoué
#include <fcntl.h>      // open()
#include <termios.h>     // configuration du port série
#include <unistd.h>       // read(), close()

// Descripteur de fichier du port série (-1 = pas encore ouvert / échec)
static int fd_arduino = -1;

// Les octets reçus arrivent parfois "en morceaux" (une ligne JSON peut être
// coupée entre deux appels). On les accumule ici jusqu'à trouver un
// retour à la ligne complet.
static std::string buffer_reception;

// Dernière valeur de luminosité reçue (pour le heartbeat). -1 = jamais reçue.
static float derniere_luminosite = -1.0f;

// -----------------------------------------------------------------------
// Convertit un nombre de bauds (ex: 9600) vers la constante termios
// correspondante (ex: B9600). termios ne travaille pas avec le nombre
// brut, mais avec ces constantes prédéfinies.
// -----------------------------------------------------------------------
static speed_t vitesse_vers_termios(int baudrate) {
    switch (baudrate) {
        case 9600:   return B9600;
        case 19200:  return B19200;
        case 38400:  return B38400;
        case 57600:  return B57600;
        case 115200: return B115200;
        default:
            std::cerr << "arduino: vitesse " << baudrate << " non gérée, utilisation de 9600 par défaut" << std::endl;
            return B9600;
    }
}

bool arduino_init(const char *port, int baudrate) {
    // O_NONBLOCK : très important, ça évite que le programme reste
    // bloqué en attendant des données si l'Arduino n'envoie rien
    fd_arduino = open(port, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (fd_arduino < 0) {
        // strerror(errno) donne la VRAIE raison système : "No such file or
        // directory" (mauvais port), "Permission denied" (droits, essayez
        // sudo ou le groupe "dialout"), "Device or resource busy" (déjà
        // utilisé par un autre programme, ex: l'IDE Arduino encore ouvert)...
        std::cerr << "arduino: impossible d'ouvrir " << port
                   << " (" << std::strerror(errno) << ")" << std::endl;
        return false;
    }

    struct termios tty;
    std::memset(&tty, 0, sizeof(tty));

    if (tcgetattr(fd_arduino, &tty) != 0) {
        std::cerr << "arduino: échec de la lecture de la configuration série" << std::endl;
        close(fd_arduino);
        fd_arduino = -1;
        return false;
    }

    speed_t vitesse = vitesse_vers_termios(baudrate);
    cfsetispeed(&tty, vitesse); // vitesse en réception
    cfsetospeed(&tty, vitesse); // vitesse en émission (pas utilisée ici, mais à régler quand même)

    // Configuration "8N1" standard (8 bits de données, pas de parité, 1 bit de stop)
    tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
    tty.c_cflag &= ~PARENB;   // pas de bit de parité
    tty.c_cflag &= ~CSTOPB;   // un seul bit de stop
    tty.c_cflag &= ~CRTSCTS;  // pas de contrôle de flux matériel
    tty.c_cflag |= (CLOCAL | CREAD); // active la réception, ignore les lignes de contrôle modem

    tty.c_lflag = 0; // mode "brut" : pas de traitement des caractères spéciaux
    tty.c_oflag = 0;
    tty.c_iflag &= ~(IXON | IXOFF | IXANY); // pas de contrôle de flux logiciel
    tty.c_iflag &= ~ICRNL; // NE PAS traduire les retours chariot (\r) en \n :
                             // Serial.println() côté Arduino envoie "\r\n", et
                             // sans ça, le \r se change en \n fantôme, créant
                             // une ligne vide juste après chaque vrai message

    // VMIN=0, VTIME=0 : lecture non bloquante (read() retourne immédiatement,
    // même s'il n'y a rien à lire)
    tty.c_cc[VMIN] = 0;
    tty.c_cc[VTIME] = 0;

    if (tcsetattr(fd_arduino, TCSANOW, &tty) != 0) {
        std::cerr << "arduino: échec de l'application de la configuration série" << std::endl;
        close(fd_arduino);
        fd_arduino = -1;
        return false;
    }

    std::cout << "arduino: liaison série ouverte sur " << port << std::endl;
    return true;
}

void arduino_cleanup() {
    if (fd_arduino >= 0) {
        close(fd_arduino);
        fd_arduino = -1;
    }
}

// -----------------------------------------------------------------------
// Même petite fonction d'extraction JSON que dans network.cpp (le champ
// "capteur" de la ligne envoyée par l'Arduino, ex: {"capteur":"bouton"})
// -----------------------------------------------------------------------
static std::string extraire_champ_json(const std::string &ligne, const std::string &champ) {
    std::string cle = "\"" + champ + "\"";
    size_t pos = ligne.find(cle);
    if (pos == std::string::npos) return "";

    pos = ligne.find(':', pos);
    if (pos == std::string::npos) return "";
    pos++;

    while (pos < ligne.size() && (ligne[pos] == ' ' || ligne[pos] == '"')) pos++;

    size_t fin = pos;
    while (fin < ligne.size() && ligne[fin] != '"' && ligne[fin] != ',' && ligne[fin] != '}') fin++;

    return ligne.substr(pos, fin - pos);
}

bool arduino_lire_evenement(std::string &capteur_out) {
    if (fd_arduino < 0) return false;

    // On essaie de lire ce qu'il y a de disponible (peut être 0 octet,
    // c'est normal et ce n'est PAS une erreur puisque le port est non-bloquant)
    char tampon[256];
    ssize_t nb_lus = read(fd_arduino, tampon, sizeof(tampon));

    if (nb_lus > 0) {
        buffer_reception.append(tampon, nb_lus);
    }

    // On cherche une ligne complète (terminée par un retour à la ligne)
    size_t position_retour_ligne = buffer_reception.find('\n');
    if (position_retour_ligne == std::string::npos) {
        return false; // pas encore de ligne complète, on retentera au prochain appel
    }

    // On extrait cette ligne du buffer, et on retire ce qu'on vient de
    // consommer (pour ne pas la retraiter au prochain appel)
    std::string ligne = buffer_reception.substr(0, position_retour_ligne);
    buffer_reception.erase(0, position_retour_ligne + 1);

    // Sécurité supplémentaire : si un \r a quand même survécu (autre
    // système, autre configuration série...), on le retire pour ne pas
    // fausser le contenu de la ligne.
    if (!ligne.empty() && ligne.back() == '\r') {
        ligne.pop_back();
    }

    if (ligne.empty()) {
        // Ligne vide (artefact de fin de ligne), rien à traiter : on ne
        // logue rien, ce n'est pas une vraie erreur.
        return false;
    }

    std::cout << "[arduino] ligne reçue : " << ligne << std::endl;

    std::string capteur = extraire_champ_json(ligne, "capteur");
    if (capteur.empty()) {
        std::cerr << "[arduino] ligne ignorée (pas de champ \"capteur\" exploitable) : " << ligne << std::endl;
        return false;
    }

    // Si c'est la photorésistance, on mémorise aussi sa vraie valeur
    // (utile pour le heartbeat, indépendamment du fait que ça déclenche
    // une alerte ou non)
    if (capteur == "photoresistance") {
        std::string valeur_texte = extraire_champ_json(ligne, "valeur");
        if (!valeur_texte.empty()) {
            derniere_luminosite = std::stof(valeur_texte);
        }
    }

    capteur_out = capteur;
    return true;
}

float arduino_derniere_luminosite() {
    return derniere_luminosite;
}
