import type { AuthenticatedUser } from '../types/auth'

type MockUser = AuthenticatedUser & {
  password: string
}

export const mockUsers: MockUser[] = [
  {
    id: 1,
    name: 'Mayou',
    email: 'utilisateur@particulier.com',
    password: 'utilisateur123',
    role: 'USER',
    siteId: 1,
  },
  {
    id: 2,
    name: 'entreprise',
    email: 'utilisateur@entreprise.com',
    password: 'entreprise123',
    role: 'COMPANY',
    siteId: null,
  },
]