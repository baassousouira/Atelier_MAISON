import type {
  AvailabilityPoint,
  Equipment,
  HistoryEvent,
  MediaItem,
  MotionActivityPoint,
  SecurityAlert,
} from '../types/dashboard'

/*
  ============================================================
  OUTILS DE DATE
  ============================================================

  Les événements de l'historique doivent afficher :
  JJ/MM/AAAA HH:mm:ss

  Exemple :
  03/09/2026 16:42:18
*/
function formatDateTime(date: Date) {
  return date.toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  })
}

/*
  Heure seule utilisée notamment
  pour la limite de réponse d'une alerte.
*/
function formatTime(date: Date) {
  return date.toLocaleTimeString('fr-FR', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  })
}

/*
  Renvoie une date située X minutes dans le passé.
*/
function minutesAgo(minutes: number) {
  return new Date(
    Date.now() -
      minutes * 60 * 1000,
  )
}

/*
  Renvoie une date située X heures dans le passé.
*/
function hoursAgo(hours: number) {
  return new Date(
    Date.now() -
      hours * 60 * 60 * 1000,
  )
}

/*
  ============================================================
  ALERTE DE DÉMONSTRATION
  ============================================================

  À chaque rechargement :

  - une nouvelle alerte est simulée ;
  - l'utilisateur dispose de 2 minutes pour répondre.
*/
const demoAlertDetectedAt = new Date()

const demoAlertDeadline = new Date(
  demoAlertDetectedAt.getTime() +
    2 * 60 * 1000,
)

/*
  ============================================================
  ÉQUIPEMENTS
  ============================================================

  IMPORTANT :

  raspberryId reste uniquement une information interne.

  Elle sert au futur serveur à savoir à quel contrôleur
  envoyer une commande.

  Elle ne doit PAS être affichée dans l'application.
*/
export const initialEquipment: Equipment[] = [
  /*
    ----------------------------------------------------------
    CAMÉRA FIXE
    ----------------------------------------------------------
  */
  {
    id: 'camera-salon',
    name: 'Caméra fixe',
    location: 'Salon',

    raspberryId: 'raspberry-camera',

    kind: 'CAMERA',

    status: 'ONLINE',
    enabled: true,
    controllable: true,

    lastSeen: 'Il y a 4 secondes',
  },

  /*
    ----------------------------------------------------------
    CAPTEUR DE LUMINOSITÉ / PHOTORÉSISTANCE
    ----------------------------------------------------------

    IMPORTANT :

    La photorésistance est associée
    à la CAMÉRA FIXE.

    Elle n'est PAS sur le robot.
  */
  {
    id: 'light-sensor',
    name: 'Capteur de luminosité',
    location: 'Salon',

    /*
      Même contrôleur que la caméra fixe.
    */
    raspberryId: 'raspberry-camera',

    kind: 'PHOTORESISTOR',

    status: 'ONLINE',
    enabled: true,
    controllable: true,

    /*
      Valeur fictive actuellement remontée.
    */
    value: '62 %',

    lastSeen: 'Il y a 2 secondes',
  },

  /*
    ----------------------------------------------------------
    DÉTECTEUR DE MOUVEMENT
    ----------------------------------------------------------
  */
  {
    id: 'motion-entry',
    name: 'Détecteur de mouvement',
    location: 'Entrée',

    raspberryId: 'raspberry-sensors',

    kind: 'MOTION_SENSOR',

    status: 'ONLINE',
    enabled: true,
    controllable: true,

    lastSeen: 'Il y a 3 secondes',
  },

  /*
    ----------------------------------------------------------
    LED D'ALERTE
    ----------------------------------------------------------
  */
  {
    id: 'warning-led',
    name: "LED d'alerte",
    location: 'Entrée',

    raspberryId: 'raspberry-sensors',

    kind: 'LED',

    status: 'ONLINE',

    /*
      Désactivée au démarrage.
    */
    enabled: false,

    controllable: true,

    lastSeen: 'Il y a 5 secondes',
  },

  /*
    ----------------------------------------------------------
    CAMÉRA MOBILE DU ROBOT
    ----------------------------------------------------------
  */
  {
    id: 'camera-robot',
    name: 'Caméra mobile',
    location: 'Robot mobile',

    raspberryId: 'raspberry-robot',

    kind: 'ROBOT_CAMERA',

    status: 'ONLINE',
    enabled: true,
    controllable: true,

    lastSeen: 'Il y a 6 secondes',
  },

  /*
    ----------------------------------------------------------
    ROBOT MOBILE
    ----------------------------------------------------------

    Le robot comprend :

    - les moteurs ;
    - le déplacement ;
    - sa caméra mobile.

    La photorésistance n'en fait pas partie.
  */
  {
    id: 'robot-01',
    name: 'Robot mobile',
    location: 'Rez-de-chaussée',

    raspberryId: 'raspberry-robot',

    kind: 'ROBOT',

    status: 'ONLINE',
    enabled: true,
    controllable: true,

    lastSeen: 'Il y a 4 secondes',
  },
]

/*
  ============================================================
  STATISTIQUES : MOUVEMENTS ET ALERTES
  ============================================================
*/
export const motionActivity: MotionActivityPoint[] = [
  {
    day: 'Lun',
    detections: 2,
    alertes: 0,
  },
  {
    day: 'Mar',
    detections: 5,
    alertes: 1,
  },
  {
    day: 'Mer',
    detections: 3,
    alertes: 0,
  },
  {
    day: 'Jeu',
    detections: 8,
    alertes: 2,
  },
  {
    day: 'Ven',
    detections: 4,
    alertes: 1,
  },
  {
    day: 'Sam',
    detections: 6,
    alertes: 0,
  },
  {
    day: 'Dim',
    detections: 3,
    alertes: 1,
  },
]

/*
  ============================================================
  STATISTIQUES : DISPONIBILITÉ DU SYSTÈME
  ============================================================
*/
export const availabilityActivity: AvailabilityPoint[] = [
  {
    day: 'Lun',
    disponibilite: 100,
  },
  {
    day: 'Mar',
    disponibilite: 99.8,
  },
  {
    day: 'Mer',
    disponibilite: 100,
  },
  {
    day: 'Jeu',
    disponibilite: 99.1,
  },
  {
    day: 'Ven',
    disponibilite: 99.7,
  },
  {
    day: 'Sam',
    disponibilite: 100,
  },
  {
    day: 'Dim',
    disponibilite: 99.5,
  },
]

/*
  ============================================================
  ALERTE DE SÉCURITÉ ACTIVE
  ============================================================
*/
export const initialAlert: SecurityAlert = {
  id: 'alert-408',

  title: 'Mouvement inhabituel détecté',

  description:
    "Plusieurs mouvements ont été détectés alors que la surveillance était activée. L'événement nécessite votre réponse.",

  location: 'Salon',

  /*
    Date complète avec secondes.
  */
  detectedAt: formatDateTime(
    demoAlertDetectedAt,
  ),

  /*
    Caméra utilisée si une vérification
    vidéo est autorisée.
  */
  cameraId: 'camera-salon',

  confidence: 87,

  status: 'WAITING_RESPONSE',

  /*
    Le countdown de la page Alertes
    utilise cette heure limite.
  */
  responseDeadline: formatTime(
    demoAlertDeadline,
  ),
}

/*
  ============================================================
  MÉDIAS
  ============================================================
*/
export const initialMedia: MediaItem[] = [
  {
    id: 'media-101',

    cameraId: 'camera-salon',

    cameraName: 'Caméra fixe · Salon',

    kind: 'VIDEO',

    createdAt: formatDateTime(
      minutesAgo(15),
    ),

    /*
      Suppression automatique prévue
      dans environ 48 heures.
    */
    expiresAt: formatDateTime(
      new Date(
        Date.now() +
          48 * 60 * 60 * 1000,
      ),
    ),

    saved: false,
  },

  {
    id: 'media-102',

    cameraId: 'camera-robot',

    cameraName:
      'Caméra mobile · Robot',

    kind: 'SCREENSHOT',

    createdAt: formatDateTime(
      hoursAgo(18),
    ),

    expiresAt: formatDateTime(
      new Date(
        Date.now() +
          32 * 60 * 60 * 1000,
      ),
    ),

    saved: true,
  },
]

/*
  ============================================================
  HISTORIQUE
  ============================================================

  Chaque événement possède maintenant :

  - jour ;
  - mois ;
  - année ;
  - heure ;
  - minute ;
  - seconde.

  Exemple :
  03/09/2026 16:42:18
*/
export const initialHistory: HistoryEvent[] = [
  {
    id: 'event-01',

    timestamp: formatDateTime(
      minutesAgo(2),
    ),

    title: 'Mouvement détecté',

    description:
      'Une alerte a été créée pour le salon.',

    actor: 'Système',

    category: 'ALERT',

    status: 'WARNING',
  },

  {
    id: 'event-02',

    timestamp: formatDateTime(
      minutesAgo(37),
    ),

    title: 'Surveillance activée',

    description:
      'Le logement est passé en mode surveillé.',

    actor: 'Maïwenne',

    category: 'SYSTEM',

    status: 'SUCCESS',
  },

  {
    id: 'event-03',

    timestamp: formatDateTime(
      hoursAgo(3),
    ),

    title: 'Robot déplacé',

    description:
      'Commande exécutée : tourner à gauche.',

    actor: 'Maïwenne',

    category: 'COMMAND',

    status: 'INFO',
  },

  {
    id: 'event-04',

    timestamp: formatDateTime(
      hoursAgo(4),
    ),

    title: 'Capture sauvegardée',

    description:
      'La capture de la caméra mobile a été conservée.',

    actor: 'Maïwenne',

    category: 'MEDIA',

    status: 'SUCCESS',
  },

  {
    id: 'event-05',

    timestamp: formatDateTime(
      hoursAgo(6),
    ),

    title:
      'Caméra mobile désactivée',

    description:
      "L'équipement a confirmé le changement d'état.",

    actor: 'Maïwenne',

    category: 'COMMAND',

    status: 'INFO',
  },

  {
    id: 'event-06',

    timestamp: formatDateTime(
      hoursAgo(22),
    ),

    title: 'Connexion rétablie',

    description:
      'La communication avec le système a été rétablie.',

    actor: 'Système',

    category: 'SYSTEM',

    status: 'SUCCESS',
  },

  /*
    Événement relatif au capteur de luminosité.

    Cela permet aussi de vérifier visuellement
    qu'il est bien traité comme un équipement
    de la zone du salon.
  */
  {
    id: 'event-07',

    timestamp: formatDateTime(
      hoursAgo(26),
    ),

    title:
      'Capteur de luminosité activé',

    description:
      'La mesure de luminosité du salon est disponible pour la surveillance.',

    actor: 'Système',

    category: 'SYSTEM',

    status: 'SUCCESS',
  },
]