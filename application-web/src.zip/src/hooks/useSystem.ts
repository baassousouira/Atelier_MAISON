import { useContext } from 'react'

import {
  SystemContext,
} from '../contexts/system-context'

export function useSystem() {
  const context = useContext(SystemContext)

  /*
    Cette erreur permet de détecter immédiatement
    un composant placé en dehors du SystemProvider.
  */
  if (!context) {
    throw new Error(
      'useSystem doit être utilisé dans un SystemProvider.',
    )
  }

  return context
}