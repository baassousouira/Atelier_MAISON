// Cette "protection" produit trois comportements :

//   - aucun compte connecté → /connexion ;
//   - compte USER → espace utilisateur ;
//   - compte COMPANY → espace entreprise.

import { Navigate } from 'react-router-dom'
import type { ReactNode } from 'react'
import { useAuth } from '../hooks/useAuth'
import type { UserRole } from '../types/auth'

type ProtectedRouteProps = {
  role: UserRole
  children: ReactNode
}

function ProtectedRoute({
  role,
  children,
}: ProtectedRouteProps) {
  const { user } = useAuth()

  if (!user) {
    return <Navigate to="/connexion" replace />
  }

  if (user.role !== role) {
    const destination =
      user.role === 'COMPANY' ? '/entreprise' : '/utilisateur'

    return <Navigate to={destination} replace />
  }

  return children
}

export default ProtectedRoute