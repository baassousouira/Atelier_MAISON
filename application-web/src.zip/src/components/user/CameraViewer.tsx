import {
  useEffect,
  useState,
} from 'react'

import {
  Camera,
  EyeOff,
  Power,
  Radio,
  Save,
  WifiOff,
} from 'lucide-react'

import {
  useSystem,
} from '../../hooks/useSystem'

type CameraViewerProps = {
  /*
    Identifiant de la caméra
    dans la liste des équipements.
  */
  cameraId:
    string

  /*
    Version compacte utilisée
    dans la page Robot.
  */
  compact?:
    boolean

  /*
    Adresse HTTP du flux vidéo.

    Exemple :

    http://192.168.1.20:8080/stream.mjpg
  */
  streamUrl?:
    string
}

function CameraViewer({
  cameraId,

  compact = false,

  streamUrl,
}: CameraViewerProps) {
  const {
    equipment,

    takeScreenshot,

    toggleEquipment,

    serverConnection,
  } = useSystem()

  /*
    Le navigateur n'a pas réussi
    à charger le flux.
  */
  const [
    streamFailed,
    setStreamFailed,
  ] =
    useState(false)

  /*
    Recherche de la caméra.
  */
  const camera =
    equipment.find(
      (item) =>
        item.id ===
        cameraId,
    )

  /*
    ============================================================
    NOUVELLE TENTATIVE DU FLUX
    ============================================================

    On réinitialise l'erreur si :

    - l'URL change ;
    - la caméra change d'état ;
    - elle est rallumée ;
    - la connexion générale change.
  */
  useEffect(
    () => {
      setStreamFailed(
        false,
      )
    },
    [
      streamUrl,

      camera?.enabled,

      camera?.status,

      serverConnection.status,
    ],
  )

  /*
    Caméra inconnue.
  */
  if (
    !camera
  ) {
    return null
  }

  /*
    ============================================================
    DISPONIBILITÉ
    ============================================================

    La caméra est utilisable uniquement si :

    1. le système central est connecté ;
    2. la caméra est en ligne ;
    3. la caméra est activée.
  */
  const isAvailable =
    serverConnection.status ===
      'CONNECTED' &&

    camera.status ===
      'ONLINE' &&

    camera.enabled

  /*
    Affichage du flux uniquement si :

    - caméra disponible ;
    - URL renseignée ;
    - aucune erreur de chargement.
  */
  const canDisplayStream =
    isAvailable &&
    Boolean(
      streamUrl,
    ) &&
    !streamFailed

  /*
    État réseau global.
  */
  const serverDisconnected =
    serverConnection.status ===
    'DISCONNECTED'

  return (
    <article
      className={
        `camera-viewer ${
          compact
            ? 'is-compact'
            : ''
        }`
      }
    >
      {/*
        ========================================================
        ÉCRAN VIDÉO
        ========================================================
      */}
      <div
        className={
          `camera-screen ${
            !isAvailable
              ? 'is-unavailable'
              : ''
          }`
        }
      >
        {/*
          Un flux MJPEG peut être directement
          affiché dans une balise <img>.

          Si vous choisissez plus tard WebRTC,
          cette partie pourra être remplacée
          sans refaire toute l'interface.
        */}
        {canDisplayStream && (
          <img
            className="camera-live-image"
            src={
              streamUrl
            }
            alt={
              `Vidéo en direct de ${camera.name}`
            }
            onError={() =>
              setStreamFailed(
                true,
              )
            }
          />
        )}

        {/*
          Barre supérieure
          de la vidéo.
        */}
        <div className="camera-screen-bar">
          <span
            className={
              `live-label ${
                isAvailable
                  ? 'is-live'
                  : ''
              }`
            }
          >
            <Radio
              aria-hidden="true"
            />

            {isAvailable
              ? 'En direct'
              : 'Indisponible'}
          </span>

          <span>
            {
              camera.location
            }
          </span>
        </div>

        {/*
          ======================================================
          PLACEHOLDER
          ======================================================

          Affiché lorsqu'aucune vidéo
          ne peut être montrée.
        */}
        {!canDisplayStream && (
          <div className="camera-screen-placeholder">
            {serverDisconnected ? (
              <WifiOff
                aria-hidden="true"
              />
            ) : isAvailable ? (
              <Camera
                aria-hidden="true"
              />
            ) : (
              <EyeOff
                aria-hidden="true"
              />
            )}

            <strong>
              {serverDisconnected
                ? 'Connexion au système interrompue'

                : isAvailable
                  ? streamFailed
                    ? 'Flux vidéo inaccessible'
                    : 'Flux vidéo en attente'

                  : camera.status ===
                    'OFFLINE'
                    ? 'Caméra hors ligne'

                    : 'Caméra désactivée'}
            </strong>

            <span>
              {serverDisconnected
                ? 'La vidéo est suspendue tant que la connexion au système n’est pas rétablie.'

                : isAvailable
                  ? streamFailed
                    ? 'Vérifiez la connexion au flux vidéo.'

                    : 'Le flux vidéo sera affiché ici dès qu’il sera disponible.'

                  : camera.status ===
                    'OFFLINE'
                    ? 'La caméra ne répond pas actuellement.'

                    : 'Activez la caméra pour consulter son image.'}
            </span>
          </div>
        )}

        {/*
          Barre inférieure.
        */}
        <div className="camera-screen-footer">
          <span>
            1080p
          </span>

          <span>
            Dernier contact :
            {' '}
            {
              camera.lastSeen
            }
          </span>
        </div>
      </div>

      {/*
        ========================================================
        CONTRÔLES
        ========================================================
      */}
      <div className="camera-viewer-toolbar">
        <div>
          <strong>
            {
              camera.name
            }
          </strong>

          <span>
            <i
              className={
                `status-dot ${
                  camera.status ===
                  'ONLINE'
                    ? 'is-online'
                    : 'is-offline'
                }`
              }
            />

            {camera.status ===
            'ONLINE'
              ? camera.enabled
                ? 'Connectée et active'
                : 'Connectée · désactivée'

              : 'Hors ligne'}
          </span>
        </div>

        <div className="camera-toolbar-actions">
          {/*
            Capture.
          */}
          <button
            className="secondary-button"
            type="button"
            disabled={
              !isAvailable
            }
            onClick={() =>
              void takeScreenshot(
                camera.id,
              )
            }
          >
            <Save
              aria-hidden="true"
            />

            Capturer
          </button>

          {/*
            Activation / désactivation.

            Pas de commande possible
            si la caméra est hors ligne
            ou si le système central est inaccessible.
          */}
          <button
            className={
              camera.enabled
                ? 'danger-button'
                : 'primary-button'
            }
            type="button"
            disabled={
              camera.status ===
                'OFFLINE' ||

              serverConnection.status !==
                'CONNECTED'
            }
            onClick={() =>
              void toggleEquipment(
                camera.id,
              )
            }
          >
            <Power
              aria-hidden="true"
            />

            {camera.enabled
              ? 'Désactiver'
              : 'Activer'}
          </button>
        </div>
      </div>
    </article>
  )
}

export default CameraViewer