import {
  BadgeAlert,
  CircleCheck,
  RefreshCw,
  ShieldAlert,
  Siren,
  UserRoundCheck,
  WifiOff,
} from 'lucide-react'

import {
  useSystem,
} from '../hooks/useSystem'

import '../styles/system-connection.css'

function NetworkIncidentModal() {
  const {
    networkIncident,

    serverConnection,

    answerNetworkIncident,

    restoreConnection,
  } = useSystem()

  /*
    La popup n'est affichée que si :

    1. le serveur est inaccessible ;
    2. un incident existe ;
    3. l'utilisateur n'a pas encore répondu.
  */
  if (
    serverConnection.status !==
      'DISCONNECTED' ||
    !networkIncident ||
    networkIncident.handled
  ) {
    return null
  }

  return (
    <div
      className="network-modal-backdrop"
      role="presentation"
    >
      <section
        className="network-modal"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="network-modal-title"
      >
        <div className="network-modal-icon">
          <WifiOff
            aria-hidden="true"
          />
        </div>

        <p className="network-modal-eyebrow">
          Alerte technique
        </p>

        <h2 id="network-modal-title">
          Connexion au système interrompue
        </h2>

        <p className="network-modal-description">
          L'application ne reçoit plus
          les informations du serveur central.
          Par sécurité, toutes les commandes
          distantes sont temporairement bloquées
          jusqu'au rétablissement de la liaison.
        </p>

        <div className="network-modal-reason">
          <ShieldAlert
            aria-hidden="true"
          />

          <div>
            <strong>
              Cause détectée
            </strong>

            <span>
              {networkIncident.reason}
            </span>
          </div>
        </div>

        <p className="network-modal-question">
          Que souhaitez-vous faire
          pendant la coupure ?
        </p>

        <div className="network-modal-actions">
          <button
            type="button"
            onClick={() =>
              answerNetworkIncident(
                'SEND_AGENT',
              )
            }
          >
            <BadgeAlert
              aria-hidden="true"
            />

            <span>
              <strong>
                Envoyer un intervenant
              </strong>

              <small>
                Enregistrer une demande
                de vérification sur place.
              </small>
            </span>
          </button>

          <button
            type="button"
            onClick={() =>
              answerNetworkIncident(
                'CALL_POLICE',
              )
            }
          >
            <Siren
              aria-hidden="true"
            />

            <span>
              <strong>
                Contacter les forces de l'ordre
              </strong>

              <small>
                Enregistrer la demande
                dans le prototype.
                Aucun appel réel n'est effectué
                par cette version.
              </small>
            </span>
          </button>

          <button
            type="button"
            onClick={() =>
              answerNetworkIncident(
                'CHECK_MYSELF',
              )
            }
          >
            <UserRoundCheck
              aria-hidden="true"
            />

            <span>
              <strong>
                Je vérifie moi-même
              </strong>

              <small>
                Indiquer que vous prenez
                en charge la vérification.
              </small>
            </span>
          </button>
        </div>

        <button
          className="network-retry-button"
          type="button"
          onClick={() =>
            void restoreConnection()
          }
        >
          <RefreshCw
            aria-hidden="true"
          />

          Réessayer la connexion
        </button>

        <div className="network-prototype-note">
          <CircleCheck
            aria-hidden="true"
          />

          <span>
            Cette interface simule les actions
            extérieures. Le serveur réel décidera
            ensuite quels services peuvent
            réellement être déclenchés.
          </span>
        </div>
      </section>
    </div>
  )
}

export default NetworkIncidentModal