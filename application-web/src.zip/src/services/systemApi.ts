/*
  Couche de communication entre l'interface React et le serveur central.

  Architecture cible :
  navigateur React -> switch/réseau local -> serveur FastAPI sur le PC
  -> MQTT -> Raspberry Pi -> capteurs / caméras / robot.

  IMPORTANT : le navigateur ne contacte jamais directement un capteur.
  Le serveur reste l'unique source de vérité et applique les règles métier.
*/

const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL ??
  'http://localhost:8000/api/v1'

/*
  Par défaut le projet reste utilisable sans backend pour la démonstration.

  Pour activer le vrai serveur :
  VITE_USE_MOCK_API=false
*/
export const USE_MOCK_API =
  import.meta.env.VITE_USE_MOCK_API !== 'false'

/*
  Fonction générique utilisée pour envoyer une requête HTTP
  au serveur central.

  Si le serveur répond avec une erreur HTTP,
  une exception est déclenchée.

  Le SystemProvider interceptera cette exception
  et considérera alors que la communication
  avec le système est potentiellement interrompue.
*/
async function request(
  path: string,
  init?: RequestInit,
): Promise<void> {
  const response = await fetch(
    `${API_BASE_URL}${path}`,
    {
      ...init,

      headers: {
        'Content-Type': 'application/json',
        ...init?.headers,
      },
    },
  )

  if (!response.ok) {
    throw new Error(
      `Erreur serveur HTTP ${response.status}`,
    )
  }
}

/*
  Route très légère permettant de savoir
  si le serveur central répond encore.

  Le futur serveur FastAPI devra donc posséder :

  GET /api/v1/health
*/
export async function pingServer(): Promise<void> {
  await request('/health')
}

/*
  Active ou désactive la surveillance globale.

  Exemple JSON envoyé :

  {
    "enabled": true
  }
*/
export async function setSecurityArmed(
  enabled: boolean,
): Promise<void> {
  await request('/system/armed', {
    method: 'PUT',

    body: JSON.stringify({
      enabled,
    }),
  })
}

/*
  Active ou désactive un équipement.

  C'est cette même route qui sera utilisée
  pour les caméras, capteurs, LED ou robot.

  Le serveur décidera ensuite vers quel Raspberry
  transmettre la commande.
*/
export async function setEquipmentEnabled(
  equipmentId: string,
  enabled: boolean,
): Promise<void> {
  await request(
    `/devices/${equipmentId}/enabled`,
    {
      method: 'PUT',

      body: JSON.stringify({
        enabled,
      }),
    },
  )
}

/*
  Envoie une commande courte au robot.

  Exemple :

  {
    "command": "avancer",
    "speed": 40
  }

  FastAPI recevra cette commande puis la transmettra
  au Raspberry du robot, par exemple avec MQTT.
*/
export async function sendRobotMovement(
  command: string,
  speed: number,
): Promise<void> {
  await request('/robot/command', {
    method: 'POST',

    body: JSON.stringify({
      command,
      speed,
    }),
  })
}

/*
  Demande au serveur de créer une capture
  depuis une caméra précise.
*/
export async function requestScreenshot(
  cameraId: string,
): Promise<void> {
  await request(
    `/cameras/${cameraId}/screenshot`,
    {
      method: 'POST',
    },
  )
}

/*
  Réponse donnée par le particulier
  lors d'une alerte de sécurité.

  AUTHORIZE :
  l'entreprise peut effectuer la vérification vidéo.

  REFUSE :
  l'entreprise ne doit pas accéder à la caméra.
*/
export async function sendAlertAnswer(
  alertId: string,
  answer: 'AUTHORIZE' | 'REFUSE',
): Promise<void> {
  await request(
    `/alerts/${alertId}/answer`,
    {
      method: 'POST',

      body: JSON.stringify({
        answer,
      }),
    },
  )
}