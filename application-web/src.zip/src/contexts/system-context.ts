import { createContext } from 'react'

import type {
  AlertAnswer,
  Equipment,
  HistoryEvent,
  MediaItem,
  NetworkIncident,
  NetworkIncidentAction,
  SecurityAlert,
  ServerConnection,
} from '../types/dashboard'

/*
  Le contexte contient l'état global
  de l'installation.

  Exemple :

  si l'utilisateur désactive la caméra
  depuis la page Caméra,
  la page Equipements et les autres pages
  connaissent immédiatement le nouvel état.

  Plus tard, ces états seront synchronisés
  avec le serveur FastAPI.
*/
export type SystemContextValue = {
  isArmed: boolean

  equipment: Equipment[]

  activeAlert: SecurityAlert

  media: MediaItem[]

  history: HistoryEvent[]

  feedback: string

  /*
    Etat de la connexion :

    APP <-> SERVEUR CENTRAL
  */
  serverConnection: ServerConnection

  /*
    Incident éventuellement déclenché
    en cas de perte du serveur.
  */
  networkIncident:
    | NetworkIncident
    | null

  /*
    true :
    aucune API réelle nécessaire.

    false :
    le navigateur utilise FastAPI.
  */
  isMockMode: boolean

  /*
    Liste calculée automatiquement
    des équipements actuellement utilisables
    par les algorithmes.

    Une source désactivée disparaît immédiatement
    de cette liste.
  */
  activeDetectionSourceIds: string[]

  toggleSecuritySystem:
    () => Promise<void>

  toggleEquipment:
    (
      equipmentId: string,
    ) => Promise<void>

  answerAlert:
    (
      answer: AlertAnswer,
    ) => Promise<void>

  sendRobotCommand: (
    command: string,
    speed: number,
  ) => Promise<void>

  takeScreenshot:
    (
      cameraId: string,
    ) => Promise<void>

  toggleMediaSaved:
    (
      mediaId: string,
    ) => void

  /*
    Vérifie manuellement si
    le serveur répond.
  */
  checkServerConnection:
    () => Promise<boolean>

  /*
    Fonction uniquement prévue
    pour votre démonstration.
  */
  simulateConnectionLoss:
    () => void

  /*
    Simule un rétablissement en mode mock
    ou reteste réellement FastAPI.
  */
  restoreConnection:
    () => Promise<void>

  /*
    Enregistre la décision de l'utilisateur
    après une coupure.
  */
  answerNetworkIncident:
    (
      action: NetworkIncidentAction,
    ) => void

  clearFeedback:
    () => void
}

export const SystemContext =
  createContext<
    SystemContextValue | undefined
  >(undefined)