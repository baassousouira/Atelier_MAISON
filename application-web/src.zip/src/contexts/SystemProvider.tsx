import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react'
import type { ReactNode } from 'react'

import {
  initialAlert,
  initialEquipment,
  initialHistory,
  initialMedia,
} from '../mocks/userDashboard'

import {
  pingServer,
  requestScreenshot,
  sendAlertAnswer,
  sendRobotMovement,
  setEquipmentEnabled,
  setSecurityArmed,
  USE_MOCK_API,
} from '../services/systemApi'

import type {
  AlertAnswer,
  EquipmentKind,
  HistoryCategory,
  HistoryEvent,
  MediaItem,
  NetworkIncident,
  NetworkIncidentAction,
  ServerConnection,
} from '../types/dashboard'

import { useAuth } from '../hooks/useAuth'
import { SystemContext } from './system-context'

type SystemProviderProps = {
  children: ReactNode
}

/*
  Les équipements de cette liste peuvent fournir des données
  utilisées par la logique de surveillance.

  Une source désactivée ou hors ligne disparaît automatiquement
  de activeDetectionSourceIds : l'algorithme n'a donc pas besoin
  d'être modifié manuellement à chaque changement d'état.
*/
const DETECTION_SOURCE_KINDS: EquipmentKind[] = [
  'CAMERA',
  'ROBOT_CAMERA',
  'MOTION_SENSOR',
  'PHOTORESISTOR',
]

/*
  Format précis utilisé dans le journal d'audit.

  Exemple :
  03/09/2026 15:42:27
*/
function preciseDateTime() {
  return new Date().toLocaleString(
    'fr-FR',
    {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',

      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',

      hour12: false,
    },
  )
}

/*
  Permet de calculer une date future.

  Exemple :
  maintenant + 48 heures

  Utilisé pour l'expiration automatique
  des captures et vidéos.
*/
function dateTimeAfterHours(
  hours: number,
) {
  return new Date(
    Date.now() +
      hours *
        60 *
        60 *
        1000,
  ).toLocaleString(
    'fr-FR',
    {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',

      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',

      hour12: false,
    },
  )
}

export function SystemProvider({
  children,
}: SystemProviderProps) {
  /*
    ============================================================
    UTILISATEUR ACTUEL
    ============================================================

    Permet notamment d'enregistrer
    dans l'historique qui a effectué une action.
  */
  const {
    user,
  } = useAuth()

  /*
    ============================================================
    ÉTAT MÉTIER DE L'INSTALLATION
    ============================================================

    Les mocks servent encore de données initiales.

    Quand FastAPI sera branché,
    ces valeurs pourront être chargées
    depuis le serveur central.
  */

  /*
    Surveillance générale activée ou non.
  */
  const [
    isArmed,
    setIsArmed,
  ] = useState(true)

  /*
    Liste de tous les équipements connus.
  */
  const [
    equipment,
    setEquipment,
  ] = useState(
    initialEquipment,
  )

  /*
    Alerte actuellement active.
  */
  const [
    activeAlert,
    setActiveAlert,
  ] = useState(
    initialAlert,
  )

  /*
    Captures et vidéos.
  */
  const [
    media,
    setMedia,
  ] = useState(
    initialMedia,
  )

  /*
    Historique des événements.
  */
  const [
    history,
    setHistory,
  ] = useState(
    initialHistory,
  )

  /*
    Message affiché à l'utilisateur
    après une commande.
  */
  const [
    feedback,
    setFeedback,
  ] = useState('')

  /*
    ============================================================
    CONNEXION AU SERVEUR CENTRAL
    ============================================================

    CONNECTED :
    le serveur répond.

    CHECKING :
    une vérification est en cours.

    DISCONNECTED :
    le serveur ne répond plus.

    Dans ce dernier cas,
    toutes les commandes distantes doivent être bloquées.
  */
  const [
    serverConnection,
    setServerConnection,
  ] =
    useState<ServerConnection>({
      status:
        USE_MOCK_API
          ? 'CONNECTED'
          : 'CHECKING',

      lastContact:
        USE_MOCK_API
          ? preciseDateTime()
          : 'Aucun contact confirmé',

      failedChecks:
        0,
    })

  /*
    Incident réseau affiché au particulier.

    Il permet notamment de proposer :

    - envoyer un intervenant ;
    - contacter les forces de l'ordre ;
    - vérifier soi-même.
  */
  const [
    networkIncident,
    setNetworkIncident,
  ] =
    useState<
      NetworkIncident | null
    >(null)

  /*
    Cette valeur sert uniquement
    à la démonstration locale.

    En mode réel,
    la coupure sera constatée
    par l'échec de la route /health.
  */
  const [
    mockConnectionCut,
    setMockConnectionCut,
  ] =
    useState(false)

  /*
    ============================================================
    SOURCES PRISES EN COMPTE PAR LA SURVEILLANCE
    ============================================================

    Si la surveillance générale est désactivée,
    aucune source n'est utilisée.

    Sinon, une source doit être :

    - activée ;
    - en ligne ;
    - d'un type utile pour la détection.

    Cela répond directement à votre besoin :

    si un utilisateur désactive un capteur,
    il est automatiquement retiré des données
    exploitées par la logique de surveillance.
  */
  const activeDetectionSourceIds =
    useMemo(
      () => {
        /*
          Surveillance générale désactivée :
          aucune source active.
        */
        if (!isArmed) {
          return []
        }

        return equipment
          .filter(
            (item) =>
              item.enabled &&
              item.status ===
                'ONLINE' &&
              DETECTION_SOURCE_KINDS.includes(
                item.kind,
              ),
          )
          .map(
            (item) =>
              item.id,
          )
      },
      [
        equipment,
        isArmed,
      ],
    )

  /*
    ============================================================
    AJOUT D'UN ÉVÉNEMENT À L'HISTORIQUE
    ============================================================

    Le prototype le fait encore côté React.

    Dans la version finale,
    le serveur devra être la source de vérité
    du journal d'audit pour empêcher
    une falsification depuis le navigateur.
  */
  function addHistory(
    title: string,
    description: string,
    category:
      HistoryCategory,
  ) {
    const event:
      HistoryEvent = {
        id:
          `event-${Date.now()}-${Math.random()
            .toString(16)
            .slice(2)}`,

        /*
          DATE + HEURE + MINUTES + SECONDES.
        */
        timestamp:
          preciseDateTime(),

        title,

        description,

        actor:
          user?.name ??
          'Système',

        category,

        status:
          category ===
          'ALERT'
            ? 'WARNING'
            : 'SUCCESS',
      }

    setHistory(
      (current) => [
        event,
        ...current,
      ],
    )
  }

  /*
    ============================================================
    CRÉATION D'UN INCIDENT RÉSEAU
    ============================================================
  */
  const openNetworkIncident =
    useCallback(
      (
        reason: string,
      ) => {
        setNetworkIncident(
          (current) => {
            /*
              Un incident non traité existe déjà.

              On ne veut pas créer
              une nouvelle notification toutes les 5 secondes.
            */
            if (
              current &&
              !current.handled
            ) {
              return current
            }

            return {
              id:
                `network-${Date.now()}`,

              detectedAt:
                preciseDateTime(),

              reason,

              handled:
                false,
            }
          },
        )
      },
      [],
    )

  /*
    ============================================================
    MARQUER LE SYSTÈME COMME DÉCONNECTÉ
    ============================================================
  */
  const markDisconnected =
    useCallback(
      (
        reason: string,
      ) => {
        setServerConnection(
          (current) => ({
            status:
              'DISCONNECTED',

            /*
              On conserve le dernier
              contact réussi.
            */
            lastContact:
              current.lastContact,

            failedChecks:
              current.failedChecks +
              1,
          }),
        )

        openNetworkIncident(
          reason,
        )
      },
      [
        openNetworkIncident,
      ],
    )

  /*
    ============================================================
    MARQUER LE SYSTÈME COMME CONNECTÉ
    ============================================================
  */
  const markConnected =
    useCallback(
      () => {
        setServerConnection({
          status:
            'CONNECTED',

          lastContact:
            preciseDateTime(),

          failedChecks:
            0,
        })
      },
      [],
    )

  /*
    ============================================================
    TEST DE CONNEXION
    ============================================================

    MODE MOCK :
    on utilise mockConnectionCut.

    MODE RÉEL :
    GET /api/v1/health
  */
  const checkServerConnection =
    useCallback(
      async (): Promise<boolean> => {
        /*
          ------------------------------------------
          MODE SIMULATION
          ------------------------------------------
        */
        if (
          USE_MOCK_API
        ) {
          if (
            mockConnectionCut
          ) {
            markDisconnected(
              'La liaison de démonstration avec le système a été interrompue.',
            )

            return false
          }

          markConnected()

          return true
        }

        /*
          ------------------------------------------
          MODE RÉEL
          ------------------------------------------
        */
        setServerConnection(
          (current) => ({
            ...current,

            status:
              current.status ===
              'DISCONNECTED'
                ? 'DISCONNECTED'
                : 'CHECKING',
          }),
        )

        try {
          /*
            Route FastAPI :

            GET /api/v1/health
          */
          await pingServer()

          markConnected()

          return true
        } catch {
          /*
            Le serveur ne répond plus.
          */
          markDisconnected(
            "L'application ne reçoit plus de réponse du serveur central.",
          )

          return false
        }
      },
      [
        markConnected,
        markDisconnected,
        mockConnectionCut,
      ],
    )

  /*
    ============================================================
    SURVEILLANCE PÉRIODIQUE DU SERVEUR
    ============================================================

    En mode réel,
    le navigateur teste le serveur
    toutes les 5 secondes.
  */
  useEffect(
    () => {
      /*
        Aucun polling nécessaire
        pendant la simulation.
      */
      if (
        USE_MOCK_API
      ) {
        return undefined
      }

      /*
        Premier contrôle immédiat.
      */
      void checkServerConnection()

      /*
        Puis contrôle toutes les 5 secondes.
      */
      const intervalId =
        window.setInterval(
          () => {
            void checkServerConnection()
          },
          5000,
        )

      return () => {
        window.clearInterval(
          intervalId,
        )
      }
    },
    [
      checkServerConnection,
    ],
  )

  /*
    ============================================================
    VÉRIFICATION AVANT UNE COMMANDE
    ============================================================

    Toute commande distante passe ici.

    Si le système central est indisponible,
    aucune commande ne part.
  */
  async function requireServerConnection():
    Promise<boolean> {
    if (
      serverConnection.status ===
      'CONNECTED'
    ) {
      return true
    }

    /*
      Nouvelle tentative de connexion.
    */
    const connected =
      await checkServerConnection()

    if (
      !connected
    ) {
      setFeedback(
        'Commande impossible : la connexion avec le système est interrompue.',
      )
    }

    return connected
  }

  /*
    ============================================================
    ACTIVER / DÉSACTIVER LA SURVEILLANCE
    ============================================================
  */
  async function toggleSecuritySystem() {
    /*
      On vérifie d'abord
      que le serveur répond.
    */
    if (
      !(await requireServerConnection())
    ) {
      return
    }

    const nextValue =
      !isArmed

    const action =
      nextValue
        ? 'activée'
        : 'désactivée'

    try {
      /*
        MODE RÉEL :
        envoi vers FastAPI.
      */
      if (
        !USE_MOCK_API
      ) {
        await setSecurityArmed(
          nextValue,
        )
      }

      /*
        Mise à jour locale uniquement
        après confirmation.
      */
      setIsArmed(
        nextValue,
      )

      setFeedback(
        `La surveillance a été ${action}.`,
      )

      addHistory(
        `Surveillance ${action}`,

        'Le changement a été confirmé par le système central.',

        'SYSTEM',
      )
    } catch {
      /*
        Échec réseau.
      */
      markDisconnected(
        "La commande de surveillance n'a pas pu atteindre le serveur central.",
      )

      setFeedback(
        'La modification de la surveillance a échoué.',
      )
    }
  }

  /*
    ============================================================
    ACTIVER / DÉSACTIVER UN ÉQUIPEMENT
    ============================================================

    Cette fonction fonctionne pour :

    - caméra fixe ;
    - caméra du robot ;
    - détecteur de mouvement ;
    - LED ;
    - capteur de luminosité ;
    - robot mobile.
  */
  async function toggleEquipment(
    equipmentId: string,
  ) {
    const target =
      equipment.find(
        (item) =>
          item.id ===
          equipmentId,
      )

    /*
      Commande impossible si :

      - équipement absent ;
      - équipement hors ligne ;
      - équipement non contrôlable.
    */
    if (
      !target ||
      target.status ===
        'OFFLINE' ||
      !target.controllable
    ) {
      return
    }

    /*
      Vérification du système central.
    */
    if (
      !(await requireServerConnection())
    ) {
      return
    }

    const nextEnabledState =
      !target.enabled

    const action =
      nextEnabledState
        ? 'activé'
        : 'désactivé'

    /*
      Vérifie si ce type participe
      potentiellement aux algorithmes.
    */
    const isDetectionSource =
      DETECTION_SOURCE_KINDS.includes(
        target.kind,
      )

    try {
      /*
        MODE RÉEL :

        React
          ↓
        FastAPI
          ↓
        contrôleur matériel
          ↓
        équipement
      */
      if (
        !USE_MOCK_API
      ) {
        await setEquipmentEnabled(
          target.id,
          nextEnabledState,
        )
      }

      /*
        Mise à jour visuelle.
      */
      setEquipment(
        (current) =>
          current.map(
            (item) =>
              item.id ===
              equipmentId
                ? {
                    ...item,

                    enabled:
                      nextEnabledState,
                  }
                : item,
          ),
      )

      /*
        Message utilisateur.
      */
      setFeedback(
        isDetectionSource
          ? `${target.name} a été ${action}. La surveillance ${
              nextEnabledState
                ? 'peut maintenant utiliser ses données'
                : "l'ignore désormais"
            } automatiquement.`

          : `${target.name} a été ${action}.`,
      )

      /*
        Journal d'audit.
      */
      addHistory(
        `${target.name} ${action}`,

        isDetectionSource
          ? `La liste des sources actives a été mise à jour automatiquement pour ${target.location}.`

          : `Commande confirmée pour ${target.location}.`,

        'COMMAND',
      )
    } catch {
      markDisconnected(
        `La commande destinée à ${target.name} n'a pas pu atteindre le serveur central.`,
      )

      setFeedback(
        `Impossible de modifier ${target.name}.`,
      )
    }
  }

  /*
    ============================================================
    RÉPONSE DU PARTICULIER À UNE ALERTE
    ============================================================
  */
  async function answerAlert(
    answer:
      AlertAnswer,
  ) {
    if (
      !(await requireServerConnection())
    ) {
      return
    }

    const authorized =
      answer ===
      'AUTHORIZE'

    try {
      /*
        MODE RÉEL :
        réponse envoyée au serveur.
      */
      if (
        !USE_MOCK_API
      ) {
        await sendAlertAnswer(
          activeAlert.id,
          answer,
        )
      }

      /*
        Mise à jour du statut.
      */
      setActiveAlert(
        (current) => ({
          ...current,

          status:
            authorized
              ? 'AUTHORIZED'
              : 'REFUSED',
        }),
      )

      setFeedback(
        authorized
          ? 'La vérification a été autorisée pour cette alerte.'

          : "La vérification a été refusée. L'entreprise ne peut pas consulter la caméra pour cette alerte.",
      )

      addHistory(
        authorized
          ? 'Vérification autorisée'
          : 'Vérification refusée',

        `Réponse enregistrée pour l'alerte ${activeAlert.id}.`,

        'ALERT',
      )
    } catch {
      markDisconnected(
        "La réponse à l'alerte n'a pas pu atteindre le serveur central.",
      )

      setFeedback(
        "La réponse à l'alerte n'a pas été envoyée.",
      )
    }
  }

  /*
    ============================================================
    COMMANDES DU ROBOT
    ============================================================
  */
  async function sendRobotCommand(
    command: string,
    speed: number,
  ) {
    /*
      Impossible de piloter
      sans serveur.
    */
    if (
      !(await requireServerConnection())
    ) {
      return
    }

    try {
      if (
        !USE_MOCK_API
      ) {
        await sendRobotMovement(
          command,
          speed,
        )
      }

      setFeedback(
        `Commande envoyée au robot : ${command}, vitesse ${speed} %.`,
      )

      addHistory(
        `Robot : ${command}`,

        `Commande courte envoyée à ${speed} % de vitesse.`,

        'COMMAND',
      )
    } catch {
      markDisconnected(
        "La commande du robot n'a pas pu atteindre le serveur central.",
      )

      setFeedback(
        'Commande robot impossible.',
      )
    }
  }

  /*
    ============================================================
    CAPTURE CAMÉRA
    ============================================================
  */
  async function takeScreenshot(
    cameraId: string,
  ) {
    const camera =
      equipment.find(
        (item) =>
          item.id ===
          cameraId,
      )

    /*
      Capture impossible si
      la caméra est indisponible.
    */
    if (
      !camera ||
      !camera.enabled ||
      camera.status ===
        'OFFLINE'
    ) {
      setFeedback(
        "La capture est impossible tant que la caméra n'est pas disponible.",
      )

      return
    }

    if (
      !(await requireServerConnection())
    ) {
      return
    }

    try {
      /*
        MODE RÉEL.
      */
      if (
        !USE_MOCK_API
      ) {
        await requestScreenshot(
          cameraId,
        )
      }

      /*
        Média fictif pour le frontend.
      */
      const newMedia:
        MediaItem = {
          id:
            `media-${Date.now()}`,

          cameraId,

          cameraName:
            `${camera.name} · ${camera.location}`,

          kind:
            'SCREENSHOT',

          /*
            Date précise à la seconde.
          */
          createdAt:
            preciseDateTime(),

          /*
            Expiration dans 48h.
          */
          expiresAt:
            dateTimeAfterHours(
              48,
            ),

          saved:
            false,
        }

      setMedia(
        (current) => [
          newMedia,
          ...current,
        ],
      )

      setFeedback(
        `Une capture de ${camera.name.toLowerCase()} a été créée.`,
      )

      addHistory(
        'Capture créée',

        `Capture effectuée avec ${camera.name}.`,

        'MEDIA',
      )
    } catch {
      markDisconnected(
        "La demande de capture n'a pas pu atteindre le serveur central.",
      )

      setFeedback(
        'Capture impossible.',
      )
    }
  }

  /*
    ============================================================
    SAUVEGARDE D'UN MÉDIA
    ============================================================

    Encore local dans le prototype.
  */
  function toggleMediaSaved(
    mediaId: string,
  ) {
    const target =
      media.find(
        (item) =>
          item.id ===
          mediaId,
      )

    if (
      !target
    ) {
      return
    }

    setMedia(
      (current) =>
        current.map(
          (item) =>
            item.id ===
            mediaId
              ? {
                  ...item,

                  saved:
                    !item.saved,
                }

              : item,
        ),
    )

    setFeedback(
      target.saved
        ? 'Le média suivra de nouveau la suppression automatique.'

        : 'Le média a été sauvegardé et ne sera pas supprimé automatiquement.',
    )

    addHistory(
      target.saved
        ? 'Sauvegarde retirée'
        : 'Média sauvegardé',

      target.cameraName,

      'MEDIA',
    )
  }

  /*
    ============================================================
    SIMULER UNE COUPURE RÉSEAU
    ============================================================

    Fonction prévue pour la démonstration.
  */
  function simulateConnectionLoss() {
    /*
      Pas de simulation
      lorsque le vrai backend est activé.
    */
    if (
      !USE_MOCK_API
    ) {
      return
    }

    setMockConnectionCut(
      true,
    )

    markDisconnected(
      "Simulation : la liaison entre l'application et le système central a été coupée.",
    )

    setFeedback(
      'Simulation de coupure réseau activée.',
    )

    addHistory(
      'Perte de communication',

      "L'application ne reçoit plus de réponse du système central.",

      'SYSTEM',
    )
  }

  /*
    ============================================================
    RÉTABLIR / RETESTER LA CONNEXION
    ============================================================
  */
  async function restoreConnection() {
    /*
      MODE MOCK.
    */
    if (
      USE_MOCK_API
    ) {
      setMockConnectionCut(
        false,
      )

      markConnected()

      setNetworkIncident(
        null,
      )

      setFeedback(
        'La communication avec le système a été rétablie.',
      )

      addHistory(
        'Communication rétablie',

        'Le système central répond de nouveau.',

        'SYSTEM',
      )

      return
    }

    /*
      MODE RÉEL.
    */
    const connected =
      await checkServerConnection()

    setFeedback(
      connected
        ? 'La communication avec le système a été rétablie.'

        : 'Le système ne répond toujours pas.',
    )

    if (
      connected
    ) {
      setNetworkIncident(
        null,
      )
    }
  }

  /*
    ============================================================
    CHOIX UTILISATEUR APRÈS UNE COUPURE
    ============================================================

    Le prototype enregistre uniquement le choix.

    Il ne contacte réellement
    ni la police ni un intervenant.
  */
  function answerNetworkIncident(
    action:
      NetworkIncidentAction,
  ) {
    const labels:
      Record<
        NetworkIncidentAction,
        string
      > = {
        SEND_AGENT:
          "Demande d'envoi d'un intervenant enregistrée",

        CALL_POLICE:
          "Demande de contact des forces de l'ordre enregistrée",

        CHECK_MYSELF:
          "L'utilisateur a choisi de vérifier lui-même",
      }

    setNetworkIncident(
      (current) =>
        current
          ? {
              ...current,

              handled:
                true,

              action,
            }

          : current,
    )

    setFeedback(
      `${labels[action]}. Prototype : aucune action extérieure réelle n'est déclenchée.`,
    )

    addHistory(
      'Réponse à la coupure réseau',

      `${labels[action]}.`,

      'ALERT',
    )
  }

  /*
    Ferme simplement
    le message de confirmation.
  */
  function clearFeedback() {
    setFeedback('')
  }

  /*
    ============================================================
    EXPOSITION DU CONTEXTE
    ============================================================
  */
  return (
    <SystemContext.Provider
      value={{
        isArmed,

        equipment,

        activeAlert,

        media,

        history,

        feedback,

        serverConnection,

        networkIncident,

        isMockMode:
          USE_MOCK_API,

        activeDetectionSourceIds,

        toggleSecuritySystem,

        toggleEquipment,

        answerAlert,

        sendRobotCommand,

        takeScreenshot,

        toggleMediaSaved,

        checkServerConnection,

        simulateConnectionLoss,

        restoreConnection,

        answerNetworkIncident,

        clearFeedback,
      }}
    >
      {children}
    </SystemContext.Provider>
  )
}