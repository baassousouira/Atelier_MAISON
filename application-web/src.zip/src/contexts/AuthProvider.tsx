import { useState } from 'react'
import type { ReactNode } from 'react'
import { AuthContext } from './auth-context'
import { mockUsers } from '../mocks/users'
import type { AuthenticatedUser } from '../types/auth'

const STORAGE_KEY = 'atelier-maison-session'

type AuthProviderProps = {
  children: ReactNode
}

function readStoredUser(): AuthenticatedUser | null {
  const storedUser = sessionStorage.getItem(STORAGE_KEY)

  if (!storedUser) {
    return null
  }

  try {
    return JSON.parse(storedUser) as AuthenticatedUser
  } catch {
    sessionStorage.removeItem(STORAGE_KEY)
    return null
  }
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<AuthenticatedUser | null>(readStoredUser)

  function login(
    email: string,
    password: string,
  ): AuthenticatedUser | null {
    const account = mockUsers.find(
      (candidate) =>
        candidate.email.toLowerCase() === email.toLowerCase() &&
        candidate.password === password,
    )

    if (!account) {
      return null
    }

    const authenticatedUser: AuthenticatedUser = {
      id: account.id,
      name: account.name,
      email: account.email,
      role: account.role,
      siteId: account.siteId,
    }

    sessionStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(authenticatedUser),
    )

    setUser(authenticatedUser)

    return authenticatedUser
  }

  function logout() {
    sessionStorage.removeItem(STORAGE_KEY)
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}