//Le contexte permettra à toutes les pages de savoir 
// quel compte est connecté sans transmettre manuellement 
// l’utilisateur de composant en composant

import { createContext } from 'react'
import type { AuthenticatedUser } from '../types/auth'

export type AuthContextValue = {
  user: AuthenticatedUser | null
  login: (email: string, password: string) => AuthenticatedUser | null
  logout: () => void
}

export const AuthContext = createContext<AuthContextValue | undefined>(
  undefined,
)