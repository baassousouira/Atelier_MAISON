import {
  Navigate,
  Route,
  Routes,
} from 'react-router-dom'

import ProtectedRoute
  from './components/ProtectedRoute'

import UserLayout
  from './components/user/UserLayout'

import {
  SystemProvider,
} from './contexts/SystemProvider'

import CompanyDashboardPage
  from './pages/CompanyDashboardPage'

import LoginPage
  from './pages/LoginPage'

import UserAlertsPage
  from './pages/UserAlertsPage'

import UserCamerasPage
  from './pages/UserCamerasPage'

import UserDashboardPage
  from './pages/UserDashboardPage'

import UserEquipmentDetailPage
  from './pages/UserEquipmentDetailPage'

import UserEquipmentPage
  from './pages/UserEquipmentPage'

import UserHistoryPage
  from './pages/UserHistoryPage'

import UserRobotPage
  from './pages/UserRobotPage'

import UserStatisticsPage
  from './pages/UserStatisticspage'

function App() {
  return (
    <Routes>
      {/*
        L'adresse racine ne contient
        aucune page fonctionnelle.

        On redirige donc vers
        l'écran de connexion.
      */}
      <Route
        path="/"
        element={
          <Navigate
            to="/connexion"
            replace
          />
        }
      />

      <Route
        path="/connexion"
        element={
          <LoginPage />
        }
      />

      {/*
        ========================================================
        ESPACE PARTICULIER
        ========================================================

        Toutes les sous-pages partagent
        le même SystemProvider.

        Cela permet par exemple :

        - de désactiver une caméra ;
        - changer de page ;
        - retrouver la caméra toujours désactivée.
      */}
      <Route
        path="/utilisateur"
        element={
          <ProtectedRoute role="USER">
            <SystemProvider>
              <UserLayout />
            </SystemProvider>
          </ProtectedRoute>
        }
      >
        {/*
          /utilisateur
        */}
        <Route
          index
          element={
            <UserDashboardPage />
          }
        />

        {/*
          /utilisateur/alertes
        */}
        <Route
          path="alertes"
          element={
            <UserAlertsPage />
          }
        />

        {/*
          /utilisateur/cameras
        */}
        <Route
          path="cameras"
          element={
            <UserCamerasPage />
          }
        />

        {/*
          /utilisateur/robot
        */}
        <Route
          path="robot"
          element={
            <UserRobotPage />
          }
        />

        {/*
          Liste générale
          des équipements.
        */}
        <Route
          path="equipements"
          element={
            <UserEquipmentPage />
          }
        />

        {/*
          ======================================================
          FICHE DÉTAILLÉE D'UN ÉQUIPEMENT
          ======================================================

          Exemples :

          /utilisateur/equipements/camera-salon

          /utilisateur/equipements/light-sensor

          /utilisateur/equipements/motion-entry
        */}
        <Route
          path="equipements/:equipmentId"
          element={
            <UserEquipmentDetailPage />
          }
        />

        {/*
          /utilisateur/statistiques
        */}
        <Route
          path="statistiques"
          element={
            <UserStatisticsPage />
          }
        />

        {/*
          /utilisateur/historique
        */}
        <Route
          path="historique"
          element={
            <UserHistoryPage />
          }
        />

        {/*
          Mauvaise sous-route utilisateur :
          retour à l'accueil particulier.
        */}
        <Route
          path="*"
          element={
            <Navigate
              to="/utilisateur"
              replace
            />
          }
        />
      </Route>

      {/*
        ========================================================
        ESPACE ENTREPRISE
        ========================================================

        L'espace entreprise utilise lui aussi
        le SystemProvider.

        Il accède donc au même modèle :

        - équipements ;
        - alertes ;
        - connexion ;
        - activation/désactivation ;
        - sources utilisées par la surveillance.
      */}
      <Route
        path="/entreprise"
        element={
          <ProtectedRoute role="COMPANY">
            <SystemProvider>
              <CompanyDashboardPage />
            </SystemProvider>
          </ProtectedRoute>
        }
      />

      {/*
        Toute autre URL inconnue
        retourne à la connexion.
      */}
      <Route
        path="*"
        element={
          <Navigate
            to="/connexion"
            replace
          />
        }
      />
    </Routes>
  )
}

export default App