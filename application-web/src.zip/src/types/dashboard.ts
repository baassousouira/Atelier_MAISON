/*
  Liste des catégories d'équipements reconnues
  par l'application.

  Le serveur devra utiliser exactement
  les mêmes valeurs dans ses réponses JSON.
*/
export type EquipmentKind =
  | 'CAMERA'
  | 'ROBOT_CAMERA'
  | 'MOTION_SENSOR'
  | 'LED'
  | 'PHOTORESISTOR'
  | 'ROBOT'

export type EquipmentStatus =
  | 'ONLINE'
  | 'OFFLINE'

/*
  Structure commune à tous les équipements.

  raspberryId permet de savoir
  à quel Raspberry physique
  l'équipement est relié.
*/
export type Equipment = {
  id: string

  name: string

  location: string

  raspberryId:
    | 'raspberry-camera'
    | 'raspberry-sensors'
    | 'raspberry-robot'

  kind: EquipmentKind

  status: EquipmentStatus

  /*
    enabled représente l'état fonctionnel.

    Exemple :

    enabled = false

    signifie que le serveur doit ignorer
    cette caméra ou ce capteur dans ses algorithmes.
  */
  enabled: boolean

  /*
    controllable indique si l'utilisateur
    peut demander un changement d'état.
  */
  controllable: boolean

  /*
    Certains équipements peuvent fournir
    une valeur.

    Exemple :

    photorésistance -> "62 %"
  */
  value?: string

  /*
    Dernier moment où le serveur
    a reçu des informations de l'équipement.
  */
  lastSeen: string
}

/*
  Données du graphique mouvements / alertes.
*/
export type MotionActivityPoint = {
  day: string
  detections: number
  alertes: number
}

/*
  Données du graphique
  de disponibilité réseau.
*/
export type AvailabilityPoint = {
  day: string
  disponibilite: number
}

export type EventStatus =
  | 'SUCCESS'
  | 'WARNING'
  | 'INFO'

export type HistoryCategory =
  | 'ALERT'
  | 'COMMAND'
  | 'SYSTEM'
  | 'MEDIA'

/*
  Une entrée du journal d'audit.

  Le véritable serveur ajoutera également
  l'identifiant du compte,
  l'adresse IP
  et l'identifiant de l'installation.
*/
export type HistoryEvent = {
  id: string

  timestamp: string

  title: string

  description: string

  actor: string

  category: HistoryCategory

  status: EventStatus
}

export type AlertStatus =
  | 'WAITING_RESPONSE'
  | 'AUTHORIZED'
  | 'REFUSED'
  | 'RESOLVED'

/*
  Alerte de sécurité créée
  par le serveur central.
*/
export type SecurityAlert = {
  id: string

  title: string

  description: string

  location: string

  detectedAt: string

  cameraId: string

  confidence: number

  status: AlertStatus

  responseDeadline: string
}

export type MediaKind =
  | 'SCREENSHOT'
  | 'VIDEO'

/*
  Représente une capture ou une vidéo.

  Un média non sauvegardé sera
  supprimé après expiresAt.
*/
export type MediaItem = {
  id: string

  cameraId: string

  cameraName: string

  kind: MediaKind

  createdAt: string

  expiresAt: string

  saved: boolean
}

export type AlertAnswer =
  | 'AUTHORIZE'
  | 'REFUSE'

/*
  Etat de la liaison entre
  l'application et le serveur central.

  CHECKING :
  vérification en cours.

  CONNECTED :
  le serveur répond.

  DISCONNECTED :
  aucune réponse du serveur.
  Les commandes distantes doivent
  alors être bloquées.
*/
export type ServerConnectionStatus =
  | 'CHECKING'
  | 'CONNECTED'
  | 'DISCONNECTED'

export type ServerConnection = {
  status: ServerConnectionStatus

  lastContact: string

  /*
    Nombre d'échecs successifs observés.

    Plus tard, cette valeur pourra servir
    à différencier une micro-coupure
    d'une vraie panne réseau.
  */
  failedChecks: number
}

/*
  Réponses proposées à l'utilisateur
  lorsque le système n'est plus joignable.
*/
export type NetworkIncidentAction =
  | 'SEND_AGENT'
  | 'CALL_POLICE'
  | 'CHECK_MYSELF'

/*
  Incident créé lorsque l'application
  perd la communication avec le serveur.
*/
export type NetworkIncident = {
  id: string

  detectedAt: string

  reason: string

  /*
    false :
    l'utilisateur n'a encore choisi aucune réponse.

    true :
    une décision a été enregistrée.
  */
  handled: boolean

  action?: NetworkIncidentAction
}