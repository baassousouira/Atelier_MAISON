export type UserRole = 'USER' | 'COMPANY'

export type AuthenticatedUser = {
  id: number
  name: string
  email: string
  role: UserRole
  siteId: number | null
}