import {
  useState,
} from 'react'

import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Bot,
  Camera,
  Gauge,
  RotateCcw,
  Square,
  Wifi,
  WifiOff,
} from 'lucide-react'

import CameraViewer
  from '../components/user/CameraViewer'

import {
  useSystem,
} from '../hooks/useSystem'

function UserRobotPage() {
  /*
    ============================================================
    ÉTAT GLOBAL
    ============================================================

    La page Robot utilise uniquement :

    - le robot ;
    - sa caméra mobile ;
    - les commandes de déplacement.

    La photorésistance n'est PAS utilisée ici
    puisqu'elle appartient à la caméra fixe.
  */
  const {
    equipment,

    sendRobotCommand,

    takeScreenshot,

    serverConnection,
  } = useSystem()

  /*
    Vitesse actuellement sélectionnée.
  */
  const [
    speed,
    setSpeed,
  ] =
    useState(40)

  /*
    ============================================================
    ROBOT
    ============================================================
  */
  const robot =
    equipment.find(
      (item) =>
        item.id ===
        'robot-01',
    )

  /*
    ============================================================
    CAMÉRA MOBILE
    ============================================================
  */
  const camera =
    equipment.find(
      (item) =>
        item.id ===
        'camera-robot',
    )

  /*
    Flux vidéo du robot.

    À configurer dans :

    .env.local

    VITE_ROBOT_CAMERA_STREAM_URL=...
  */
  const robotStreamUrl =
    import.meta.env
      .VITE_ROBOT_CAMERA_STREAM_URL

  /*
    ============================================================
    AUTORISATION DE PILOTAGE
    ============================================================

    Le robot peut être déplacé uniquement si :

    1. le système central est connecté ;
    2. le robot est en ligne ;
    3. le robot est activé ;
    4. la caméra mobile est en ligne ;
    5. la caméra mobile est activée.

    Cela permet d'éviter un pilotage sans retour vidéo.
  */
  const canMove =
    serverConnection.status ===
      'CONNECTED' &&

    robot?.status ===
      'ONLINE' &&

    robot.enabled &&

    camera?.status ===
      'ONLINE' &&

    camera.enabled

  /*
    La caméra peut être utilisée
    uniquement si elle est disponible.
  */
  const canUseCamera =
    serverConnection.status ===
      'CONNECTED' &&

    camera?.status ===
      'ONLINE' &&

    camera.enabled

  /*
    ============================================================
    COMMANDE DE DÉPLACEMENT
    ============================================================
  */
  function command(
    label: string,
  ) {
    if (
      !canMove
    ) {
      return
    }

    void sendRobotCommand(
      label,
      speed,
    )
  }

  return (
    <div className="user-page">
      {/*
        ========================================================
        EN-TÊTE
        ========================================================
      */}
      <header className="page-heading">
        <div>
          <p className="page-eyebrow">
            Caméra mobile
          </p>

          <h1>
            Piloter le robot
          </h1>

          <p>
            Consultez le direct
            et contrôlez les déplacements
            depuis le même écran.
          </p>
        </div>

        <span
          className={
            `page-status ${
              canMove
                ? 'is-success'
                : 'is-warning'
            }`
          }
        >
          {canMove ? (
            <Wifi
              aria-hidden="true"
            />
          ) : (
            <WifiOff
              aria-hidden="true"
            />
          )}

          {canMove
            ? 'Prêt à piloter'
            : 'Pilotage indisponible'}
        </span>
      </header>

      <div className="robot-workspace">
        {/*
          ======================================================
          FLUX CAMÉRA MOBILE
          ======================================================
        */}
        <div className="robot-live-panel">
          <CameraViewer
            cameraId="camera-robot"
            streamUrl={
              robotStreamUrl
            }
            compact
          />
        </div>

        {/*
          ======================================================
          INFORMATIONS DU ROBOT
          ======================================================

          Seulement :

          - vitesse ;
          - état du robot.

          PAS de luminosité.
        */}
        <div className="robot-telemetry-grid robot-telemetry-grid-compact">
          <article>
            <Gauge
              aria-hidden="true"
            />

            <span>
              <small>
                Vitesse choisie
              </small>

              <strong>
                {speed}
                {' %'}
              </strong>
            </span>
          </article>

          <article>
            <Bot
              aria-hidden="true"
            />

            <span>
              <small>
                État du robot
              </small>

              <strong>
                {canMove
                  ? 'Disponible'
                  : 'À vérifier'}
              </strong>
            </span>
          </article>
        </div>

        {/*
          ======================================================
          CONSOLE DE PILOTAGE
          ======================================================
        */}
        <section className="robot-command-console">
          <div className="command-console-heading">
            <span>
              <Bot
                aria-hidden="true"
              />
            </span>

            <div>
              <p>
                Contrôle manuel
              </p>

              <h2>
                Déplacement
              </h2>
            </div>
          </div>

          <p className="command-help">
            Chaque appui envoie une commande courte.
            Le robot s&apos;arrête automatiquement
            si aucune nouvelle commande
            n&apos;est reçue.
          </p>

          {/*
            ====================================================
            VITESSE
            ====================================================
          */}
          <div className="speed-control">
            <div>
              <label htmlFor="robot-speed">
                Vitesse
              </label>

              <strong>
                {speed}
                {' %'}
              </strong>
            </div>

            <input
              id="robot-speed"
              type="range"
              min="20"
              max="80"
              step="10"
              value={
                speed
              }
              disabled={
                !canMove
              }
              onChange={(
                event,
              ) => {
                setSpeed(
                  Number(
                    event.target.value,
                  ),
                )
              }}
            />

            <div className="speed-labels">
              <span>
                Précise
              </span>

              <span>
                Rapide
              </span>
            </div>
          </div>

          {/*
            ====================================================
            COMMANDES DIRECTIONNELLES
            ====================================================
          */}
          <div
            className="direction-pad"
            aria-label="Commandes directionnelles"
          >
            <button
              className="direction-up"
              type="button"
              aria-label="Faire avancer le robot"
              disabled={
                !canMove
              }
              onClick={() =>
                command(
                  'avancer',
                )
              }
            >
              <ArrowUp
                aria-hidden="true"
              />

              <span>
                Avancer
              </span>
            </button>

            <button
              className="direction-left"
              type="button"
              aria-label="Tourner à gauche"
              disabled={
                !canMove
              }
              onClick={() =>
                command(
                  'tourner à gauche',
                )
              }
            >
              <ArrowLeft
                aria-hidden="true"
              />

              <span>
                Gauche
              </span>
            </button>

            {/*
              ARRÊT IMMÉDIAT.

              Celui-ci reste accessible
              tant que le système central
              peut recevoir la commande.
            */}
            <button
              className="direction-stop"
              type="button"
              aria-label="Arrêter immédiatement le robot"
              disabled={
                serverConnection.status !==
                'CONNECTED'
              }
              onClick={() => {
                void sendRobotCommand(
                  'arrêt immédiat',
                  0,
                )
              }}
            >
              <Square
                aria-hidden="true"
              />

              <span>
                Arrêt
              </span>
            </button>

            <button
              className="direction-right"
              type="button"
              aria-label="Tourner à droite"
              disabled={
                !canMove
              }
              onClick={() =>
                command(
                  'tourner à droite',
                )
              }
            >
              <ArrowRight
                aria-hidden="true"
              />

              <span>
                Droite
              </span>
            </button>

            <button
              className="direction-down"
              type="button"
              aria-label="Faire reculer le robot"
              disabled={
                !canMove
              }
              onClick={() =>
                command(
                  'reculer',
                )
              }
            >
              <ArrowDown
                aria-hidden="true"
              />

              <span>
                Reculer
              </span>
            </button>
          </div>

          {/*
            ====================================================
            ACTIONS COMPLÉMENTAIRES
            ====================================================
          */}
          <div className="robot-secondary-actions">
            <button
              className="secondary-button"
              type="button"
              disabled={
                !canUseCamera
              }
              onClick={() => {
                void takeScreenshot(
                  'camera-robot',
                )
              }}
            >
              <Camera
                aria-hidden="true"
              />

              Capturer l&apos;image
            </button>

            <button
              className="secondary-button"
              type="button"
              disabled={
                !canMove
              }
              onClick={() => {
                void sendRobotCommand(
                  'demi-tour',
                  speed,
                )
              }}
            >
              <RotateCcw
                aria-hidden="true"
              />

              Demi-tour
            </button>
          </div>
        </section>
      </div>
    </div>
  )
}

export default UserRobotPage