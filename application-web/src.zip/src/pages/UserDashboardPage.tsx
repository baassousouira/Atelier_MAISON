import {
  Activity,
  AlertTriangle,
  ArrowRight,
  BellRing,
  Bot,
  Camera,
  Cpu,
  Power,
  ShieldCheck,
  Wifi,
  WifiOff,
} from 'lucide-react'

import {
  Link,
} from 'react-router-dom'

import MetricCard
  from '../components/user/MetricCard'

import {
  useAuth,
} from '../hooks/useAuth'

import {
  useSystem,
} from '../hooks/useSystem'

function UserDashboardPage() {
  /*
    ============================================================
    UTILISATEUR
    ============================================================
  */
  const {
    user,
  } = useAuth()

  /*
    ============================================================
    SYSTÈME
    ============================================================
  */
  const {
    activeAlert,

    equipment,

    isArmed,

    serverConnection,

    toggleSecuritySystem,
  } = useSystem()

  /*
    Nombre d'équipements connus
    comme actuellement joignables.
  */
  const onlineCount =
    equipment.filter(
      (item) =>
        item.status ===
        'ONLINE',
    ).length

  /*
    Alerte en attente d'une réponse.
  */
  const hasPendingAlert =
    activeAlert.status ===
    'WAITING_RESPONSE'

  /*
    Le système central répond-il ?
  */
  const systemConnected =
    serverConnection.status ===
    'CONNECTED'

  /*
    Texte de bienvenue.

    Le compte générique "Particulier"
    n'est pas affiché comme prénom.
  */
  const greeting =
    user?.name &&
    user.name.toLowerCase() !==
      'particulier'
      ? `Bonjour ${user.name}`
      : 'Bonjour'

  return (
    <div className="user-page dashboard-page">
      {/*
        ========================================================
        EN-TÊTE
        ========================================================
      */}
      <header className="page-heading">
        <div>
          <p className="page-eyebrow">
            Vue d’ensemble
          </p>

          <h1>
            {greeting}
          </h1>

          <p>
            Consultez l’état de votre logement
            et accédez rapidement à chaque équipement.
          </p>
        </div>

        {/*
          Contrôle général de la surveillance.

          Il est bloqué si le serveur central
          ne répond plus.
        */}
        <button
          className={
            `system-power ${
              isArmed
                ? 'is-armed'
                : 'is-disarmed'
            }`
          }
          type="button"
          disabled={
            !systemConnected
          }
          onClick={() =>
            void toggleSecuritySystem()
          }
        >
          <Power
            aria-hidden="true"
          />

          <span>
            <small>
              Surveillance
            </small>

            <strong>
              {isArmed
                ? 'Activée'
                : 'Désactivée'}
            </strong>
          </span>
        </button>
      </header>

      {/*
        ========================================================
        PROTECTION DU LOGEMENT
        ========================================================
      */}
      <section
        className={
          `protection-hero ${
            isArmed
              ? 'is-armed'
              : 'is-disarmed'
          }`
        }
      >
        <span className="protection-hero-icon">
          <ShieldCheck
            aria-hidden="true"
          />
        </span>

        <div>
          <span>
            {isArmed
              ? 'Protection active'
              : 'Protection inactive'}
          </span>

          <h2>
            {isArmed
              ? 'Votre logement est actuellement surveillé'
              : 'Les détections automatiques sont suspendues'}
          </h2>

          <p>
            {!systemConnected
              ? 'La connexion avec le système est interrompue. Les commandes à distance sont suspendues jusqu’au rétablissement de la liaison.'

              : isArmed
                ? 'Les équipements actifs participent automatiquement à la surveillance.'

                : 'Vous pouvez toujours consulter vos équipements et réactiver la surveillance lorsque vous le souhaitez.'}
          </p>
        </div>

        <button
          type="button"
          disabled={
            !systemConnected
          }
          onClick={() =>
            void toggleSecuritySystem()
          }
        >
          {isArmed
            ? 'Désactiver'
            : 'Activer'}
        </button>
      </section>

      {/*
        ========================================================
        ALERTE PRIORITAIRE
        ========================================================

        Le countdown détaillé se trouve
        maintenant dans la page Alertes.

        On ne duplique pas ici
        un second chronomètre.
      */}
      {hasPendingAlert && (
        <section className="overview-alert">
          <span className="overview-alert-icon">
            <AlertTriangle
              aria-hidden="true"
            />
          </span>

          <div>
            <span>
              Alerte prioritaire
            </span>

            <h2>
              {
                activeAlert.title
              }
            </h2>

            <p>
              {
                activeAlert.location
              }
              {' · '}
              {
                activeAlert.detectedAt
              }
              .
              {' '}
              Une réponse est nécessaire
              pour cette détection.
            </p>
          </div>

          <Link to="/utilisateur/alertes">
            Répondre

            <ArrowRight
              aria-hidden="true"
            />
          </Link>
        </section>
      )}

      {/*
        ========================================================
        INDICATEURS
        ========================================================
      */}
      <section
        className="overview-metrics"
        aria-labelledby="metrics-title"
      >
        <div className="section-heading section-heading-compact">
          <div>
            <p className="page-eyebrow">
              Aujourd’hui
            </p>

            <h2 id="metrics-title">
              État en un coup d’œil
            </h2>
          </div>
        </div>

        <div
          className="metric-grid"
          aria-label="Indicateurs principaux"
        >
          <MetricCard
            icon={
              Activity
            }
            label="Mouvements"
            value="3"
            detail="2 de moins qu’hier"
            tone="teal"
          />

          <MetricCard
            icon={
              BellRing
            }
            label="Alertes à vérifier"
            value={
              hasPendingAlert
                ? '1'
                : '0'
            }
            detail={
              hasPendingAlert
                ? 'Réponse nécessaire'
                : 'Aucune urgence'
            }
            tone="red"
          />

          <MetricCard
            icon={
              Cpu
            }
            label="Équipements"
            value={
              systemConnected
                ? `${onlineCount}/${equipment.length}`
                : '—'
            }
            detail={
              systemConnected
                ? 'Installation disponible'
                : 'Connexion interrompue'
            }
            tone="blue"
          />

          <MetricCard
            icon={
              systemConnected
                ? Wifi
                : WifiOff
            }
            label="Connexion"
            value={
              systemConnected
                ? 'Active'
                : 'Coupée'
            }
            detail={
              `Dernier contact : ${serverConnection.lastContact}`
            }
            tone="purple"
          />
        </div>
      </section>

      {/*
        ========================================================
        ACCÈS RAPIDES
        ========================================================
      */}
      <section className="overview-components">
        <div className="section-heading">
          <div>
            <p className="page-eyebrow">
              Accès rapides
            </p>

            <h2>
              Contrôler mon installation
            </h2>
          </div>
        </div>

        <div className="component-card-grid">
          {/*
            ----------------------------------------------------
            CAMÉRA FIXE
            ----------------------------------------------------
          */}
          <Link
            className="component-card component-card-camera"
            to="/utilisateur/cameras"
          >
            <span className="component-card-icon">
              <Camera
                aria-hidden="true"
              />
            </span>

            <div>
              <span>
                Vidéo fixe
              </span>

              <h3>
                Caméra du salon
              </h3>

              <p>
                Consulter le direct,
                activer ou désactiver la caméra
                et gérer ses médias.
              </p>
            </div>

            <ArrowRight
              aria-hidden="true"
            />
          </Link>

          {/*
            ----------------------------------------------------
            ROBOT
            ----------------------------------------------------
          */}
          <Link
            className="component-card component-card-robot"
            to="/utilisateur/robot"
          >
            <span className="component-card-icon">
              <Bot
                aria-hidden="true"
              />
            </span>

            <div>
              <span>
                Caméra mobile
              </span>

              <h3>
                Robot caméra
              </h3>

              <p>
                Voir le direct et déplacer le robot
                depuis le même écran.
              </p>
            </div>

            <ArrowRight
              aria-hidden="true"
            />
          </Link>

          {/*
            ----------------------------------------------------
            ÉQUIPEMENTS
            ----------------------------------------------------

            Aucune mention visible du matériel
            informatique interne.
          */}
          <Link
            className="component-card"
            to="/utilisateur/equipements"
          >
            <span className="component-card-icon">
              <Cpu
                aria-hidden="true"
              />
            </span>

            <div>
              <span>
                Installation
              </span>

              <h3>
                Mes équipements
              </h3>

              <p>
                Gérer les caméras,
                les capteurs,
                les alertes locales
                et le robot depuis un seul espace.
              </p>
            </div>

            <ArrowRight
              aria-hidden="true"
            />
          </Link>

          {/*
            ----------------------------------------------------
            STATISTIQUES
            ----------------------------------------------------
          */}
          <Link
            className="component-card"
            to="/utilisateur/statistiques"
          >
            <span className="component-card-icon">
              <Activity
                aria-hidden="true"
              />
            </span>

            <div>
              <span>
                Analyse
              </span>

              <h3>
                Statistiques détaillées
              </h3>

              <p>
                Visualiser les mouvements,
                les alertes et la disponibilité
                de l’installation.
              </p>
            </div>

            <ArrowRight
              aria-hidden="true"
            />
          </Link>
        </div>
      </section>
    </div>
  )
}

export default UserDashboardPage