import { useState } from 'react'
import type { FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import '../styles/login.css'

function LoginPage() {
  const navigate = useNavigate()
  const { login } = useAuth()

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [feedback, setFeedback] = useState('')

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()

    if (!email.trim() || !password) {
      setFeedback('Renseignez votre adresse e-mail et votre mot de passe.')
      return
    }

    const authenticatedUser = login(email.trim(), password)

    if (!authenticatedUser) {
      setFeedback('Adresse e-mail ou mot de passe incorrect.')
      return
    }

    const destination =
      authenticatedUser.role === 'COMPANY'
        ? '/entreprise'
        : '/utilisateur'

    navigate(destination, { replace: true })
  }

  return (
    <main className="login-shell">
      <section
        className="login-introduction"
        aria-label="Présentation d’Atelier Maison"
      >
        <header className="brand">
          <span className="brand-mark" aria-hidden="true">
            AM
          </span>

          <div>
            <p className="brand-name">Verisafe</p>
            <p className="brand-description">Supervision domestique</p>
          </div>
        </header>

        <div className="introduction-content">
          <p className="introduction-label">
            Système de surveillance connecté
          </p>

          <h1>Gardez le contrôle de votre installation.</h1>

          <p className="introduction-text">
            Consultez vos équipements, vérifiez les alertes et pilotez
            votre système depuis une interface centralisée.
          </p>

          <div className="network-card">
            <div className="network-icon" aria-hidden="true">
              <span />
              <span />
              <span />
            </div>

            <div>
              <p className="network-title">Supervision hyper sécurisée</p>
              <p className="network-text">
                Plusieurs caméras et capteurs 
              </p>
            </div>
          </div>
        </div>

        <div
          className="system-summary"
          aria-label="Fonctions du système"
        >
          <div>
            <strong>3 500</strong>
            <span>Cambriolage intercepté</span>
          </div>

          <div>
            <strong>48 h</strong>
            <span>Historique</span>
          </div>

          <div>
            <strong>1</strong>
            <span>Contrôle total</span>
          </div>
        </div>
      </section>

      <section className="login-area">
        <div className="mobile-brand">
          <span className="brand-mark" aria-hidden="true">
            AM
          </span>

          <span>Atelier Maison</span>
        </div>

        <div className="login-card">
          <div className="login-heading">
            <p className="login-eyebrow">Espace sécurisé</p>
            <h2>Connexion</h2>

            <p>
              Saisissez les identifiants associés à votre installation.
            </p>
          </div>

          <form onSubmit={handleSubmit} noValidate>
            <div className="form-field">
              <label htmlFor="email">Adresse e-mail</label>

              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                placeholder="nom@exemple.fr"
                value={email}
                onChange={(event) => {
                  setEmail(event.target.value)
                  setFeedback('')
                }}
              />
            </div>

            <div className="form-field">
              <div className="password-label">
                <label htmlFor="password">Mot de passe</label>

                <button
                  className="password-toggle"
                  type="button"
                  onClick={() =>
                    setShowPassword((current) => !current)
                  }
                  aria-controls="password"
                  aria-pressed={showPassword}
                >
                  {showPassword ? 'Masquer' : 'Afficher'}
                </button>
              </div>

              <input
                id="password"
                name="password"
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
                placeholder="Votre mot de passe"
                value={password}
                onChange={(event) => {
                  setPassword(event.target.value)
                  setFeedback('')
                }}
              />
            </div>

            <button className="login-button" type="submit">
              Se connecter
            </button>

            {feedback && (
              <p className="form-feedback" role="status">
                {feedback}
              </p>
            )}
          </form>

          <div className="access-information">
            <span
              className="information-icon"
              aria-hidden="true"
            >
              i
            </span>

            <p>
              Connectez-vous à votre compte pour pouvoir gérer votre système de surveillance. 
            </p>
          </div>
        </div>

        <p className="login-footer">
          Prototype Atelier MAISON · Mariam Sara Kevidu Lyna Maïwenne
        </p>
      </section>
    </main>
  )
}

export default LoginPage