import {
  Activity,
  BellRing,
  Clock3,
  ShieldCheck,
  Wifi,
} from 'lucide-react'

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
} from 'recharts'

import {
  availabilityActivity,
  motionActivity,
} from '../mocks/userDashboard'

import '../styles/statistics-page.css'

/*
  ============================================================
  NOMS COMPLETS DES JOURS
  ============================================================

  Les graphiques gardent les abréviations
  pour rester compacts.

  Le bilan utilise le nom complet.
*/
const fullDayLabels: Record<string, string> = {
  Lun: 'lundi',
  Mar: 'mardi',
  Mer: 'mercredi',
  Jeu: 'jeudi',
  Ven: 'vendredi',
  Sam: 'samedi',
  Dim: 'dimanche',
}

function UserStatisticsPage() {
  /*
    ============================================================
    CALCUL DES INDICATEURS
    ============================================================
  */

  const totalDetections =
    motionActivity.reduce(
      (
        total,
        item,
      ) =>
        total +
        item.detections,
      0,
    )

  const totalAlerts =
    motionActivity.reduce(
      (
        total,
        item,
      ) =>
        total +
        item.alertes,
      0,
    )

  const alertRate =
    totalDetections > 0
      ? Math.round(
          (
            totalAlerts /
            totalDetections
          ) *
            100,
        )
      : 0

  const averageAvailability =
    availabilityActivity.length > 0
      ? availabilityActivity.reduce(
          (
            total,
            item,
          ) =>
            total +
            item.disponibilite,
          0,
        ) /
        availabilityActivity.length
      : 0

  const averageAvailabilityLabel =
    averageAvailability.toLocaleString(
      'fr-FR',
      {
        minimumFractionDigits: 1,
        maximumFractionDigits: 1,
      },
    )

  /*
    Valeur de démonstration.

    Plus tard, cette valeur viendra
    du serveur.
  */
  const averageResponseTime =
    38

  /*
    ============================================================
    JOUR AVEC LE PLUS DE MOUVEMENTS
    ============================================================
  */

  const busiestDay =
    motionActivity.length > 0
      ? [...motionActivity].sort(
          (
            first,
            second,
          ) =>
            second.detections -
            first.detections,
        )[0]
      : null

  const busiestDayFullLabel =
    busiestDay
      ? fullDayLabels[
          busiestDay.day
        ] ??
        busiestDay.day
      : ''

  return (
    <div className="user-page stats-mobile-page">
      {/*
        ========================================================
        EN-TÊTE
        ========================================================
      */}

      <header className="page-heading stats-mobile-heading">
        <div>
          <p className="page-eyebrow">
            Analyse
          </p>

          <h1>
            Statistiques
          </h1>

          <p>
            Suivez l'activité de surveillance
            et la disponibilité de votre installation.
          </p>
        </div>
      </header>

      {/*
        ========================================================
        PÉRIODE
        ========================================================
      */}

      <section className="stats-mobile-period">
        <label
          htmlFor="statistics-period"
        >
          Période
        </label>

        <select
          id="statistics-period"
          defaultValue="7D"
        >
          <option value="7D">
            7 derniers jours
          </option>

          <option value="30D">
            30 derniers jours
          </option>

          <option value="90D">
            3 derniers mois
          </option>
        </select>
      </section>

      {/*
        ========================================================
        INDICATEURS
        ========================================================
      */}

      <section className="stats-mobile-kpi-grid">
        <article className="stats-mobile-kpi">
          <span className="stats-mobile-kpi-icon is-detection">
            <Activity
              aria-hidden="true"
            />
          </span>

          <div className="stats-mobile-kpi-copy">
            <span>
              Mouvements
            </span>

            <strong>
              {totalDetections}
            </strong>

            <small>
              7 derniers jours
            </small>
          </div>
        </article>

        <article className="stats-mobile-kpi">
          <span className="stats-mobile-kpi-icon is-alert">
            <BellRing
              aria-hidden="true"
            />
          </span>

          <div className="stats-mobile-kpi-copy">
            <span>
              Alertes
            </span>

            <strong>
              {totalAlerts}
            </strong>

            <small>
              {alertRate}
              {' % des détections'}
            </small>
          </div>
        </article>

        <article className="stats-mobile-kpi">
          <span className="stats-mobile-kpi-icon is-response">
            <Clock3
              aria-hidden="true"
            />
          </span>

          <div className="stats-mobile-kpi-copy">
            <span>
              Temps de réponse
            </span>

            <strong>
              {averageResponseTime}
              {' s'}
            </strong>

            <small>
              12 s plus rapide
            </small>
          </div>
        </article>

        <article className="stats-mobile-kpi">
          <span className="stats-mobile-kpi-icon is-availability">
            <Wifi
              aria-hidden="true"
            />
          </span>

          <div className="stats-mobile-kpi-copy">
            <span>
              Disponibilité
            </span>

            <strong>
              {averageAvailabilityLabel}
              {' %'}
            </strong>

            <small>
              Objectif &gt; 99 %
            </small>
          </div>
        </article>
      </section>

      {/*
        ========================================================
        GRAPHIQUE MOUVEMENTS / ALERTES
        ========================================================
      */}

      <section className="stats-mobile-chart-card">
        <header className="stats-mobile-chart-header">
          <div>
            <span className="stats-mobile-eyebrow">
              Détection
            </span>

            <h2>
              Mouvements et alertes
            </h2>
          </div>

          <Activity
            aria-hidden="true"
          />
        </header>

        <div className="stats-mobile-legend">
          <span>
            <i className="is-motion" />

            Mouvements
          </span>

          <span>
            <i className="is-alert" />

            Alertes
          </span>
        </div>

        <div className="stats-mobile-chart-container">
          <ResponsiveContainer
            width="100%"
            height="100%"
          >
            <AreaChart
              data={motionActivity}
              margin={{
                top: 12,
                right: 6,
                bottom: 0,
                left: 6,
              }}
            >
              <defs>
                <linearGradient
                  id="statsMotionGradient"
                  x1="0"
                  y1="0"
                  x2="0"
                  y2="1"
                >
                  <stop
                    offset="0%"
                    stopColor="#109487"
                    stopOpacity={0.18}
                  />

                  <stop
                    offset="100%"
                    stopColor="#109487"
                    stopOpacity={0}
                  />
                </linearGradient>
              </defs>

              <CartesianGrid
                vertical={false}
                strokeDasharray="4 4"
                stroke="#e2e9eb"
              />

              <XAxis
                dataKey="day"
                axisLine={false}
                tickLine={false}
                tick={{
                  fill: '#71848c',
                  fontSize: 11,
                }}
                dy={7}
              />

              <Tooltip />

              <Area
                type="monotone"
                dataKey="detections"
                name="Mouvements"
                stroke="#109487"
                strokeWidth={2.5}
                fill="url(#statsMotionGradient)"
                dot={false}
              />

              <Area
                type="monotone"
                dataKey="alertes"
                name="Alertes"
                stroke="#d95155"
                strokeWidth={2}
                fill="transparent"
                dot={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/*
        ========================================================
        DISPONIBILITÉ
        ========================================================
      */}

      <section className="stats-mobile-chart-card">
        <header className="stats-mobile-chart-header">
          <div>
            <span className="stats-mobile-eyebrow">
              Réseau
            </span>

            <h2>
              Disponibilité quotidienne
            </h2>
          </div>

          <Wifi
            aria-hidden="true"
          />
        </header>

        <div className="stats-mobile-chart-container stats-mobile-chart-container-bar">
          <ResponsiveContainer
            width="100%"
            height="100%"
          >
            <BarChart
              data={availabilityActivity}
              margin={{
                top: 12,
                right: 5,
                bottom: 0,
                left: 5,
              }}
            >
              <CartesianGrid
                vertical={false}
                strokeDasharray="4 4"
                stroke="#e2e9eb"
              />

              <XAxis
                dataKey="day"
                axisLine={false}
                tickLine={false}
                tick={{
                  fill: '#71848c',
                  fontSize: 11,
                }}
                dy={7}
              />

              <Tooltip />

              <Bar
                dataKey="disponibilite"
                name="Disponibilité"
                fill="#3478a9"
                radius={[
                  7,
                  7,
                  0,
                  0,
                ]}
                maxBarSize={38}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/*
        ========================================================
        BILAN
        ========================================================
      */}

      <section className="stats-mobile-summary">
        <span className="stats-mobile-summary-icon">
          <ShieldCheck
            aria-hidden="true"
          />
        </span>

        <div>
          <span className="stats-mobile-summary-eyebrow">
            Bilan de la période
          </span>

          <h2>
            Installation stable
          </h2>

          <p>
            Les équipements sont restés
            disponibles plus de 99 % du temps.

            {busiestDay && (
              <>
                {' '}
                Le
                {' '}
                <strong>
                  {busiestDayFullLabel}
                </strong>
                {' '}
                concentre le plus grand nombre
                de mouvements détectés.
              </>
            )}
          </p>
        </div>
      </section>
    </div>
  )
}

export default UserStatisticsPage