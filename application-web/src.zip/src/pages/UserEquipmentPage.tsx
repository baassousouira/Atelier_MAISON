import type {
  LucideIcon,
} from 'lucide-react'

import {
  Bot,
  Camera,
  Cpu,
  ShieldCheck,
} from 'lucide-react'

import EquipmentControl
  from '../components/user/EquipmentControl'

import {
  useSystem,
} from '../hooks/useSystem'

/*
  ============================================================
  GROUPES FONCTIONNELS
  ============================================================

  On ne montre PAS l'architecture matérielle
  à l'utilisateur.

  L'utilisateur voit seulement des groupes
  compréhensibles :

  - Surveillance du salon
  - Sécurité de l'entrée
  - Robot mobile
*/
type EquipmentGroup = {
  id:
    string

  title:
    string

  description:
    string

  icon:
    LucideIcon

  equipmentIds:
    string[]
}

/*
  ============================================================
  RÉPARTITION CORRECTE
  ============================================================

  SURVEILLANCE DU SALON
  - caméra fixe
  - photorésistance

  SÉCURITÉ DE L'ENTRÉE
  - détecteur mouvement
  - LED

  ROBOT
  - caméra mobile
  - moteurs / déplacement
*/
const equipmentGroups:
  EquipmentGroup[] = [
    {
      id:
        'fixed-surveillance',

      title:
        'Surveillance du salon',

      description:
        'Caméra principale et mesure de la luminosité de la zone surveillée.',

      icon:
        Camera,

      equipmentIds: [
        'camera-salon',
        'light-sensor',
      ],
    },

    {
      id:
        'entry-security',

      title:
        "Sécurité de l'entrée",

      description:
        "Détection de mouvement et signal d'alerte local.",

      icon:
        ShieldCheck,

      equipmentIds: [
        'motion-entry',
        'warning-led',
      ],
    },

    {
      id:
        'mobile-unit',

      title:
        'Robot mobile',

      description:
        'Caméra mobile et déplacement à distance.',

      icon:
        Bot,

      /*
        IMPORTANT :

        La photorésistance
        n'est PAS dans ce groupe.
      */
      equipmentIds: [
        'camera-robot',
        'robot-01',
      ],
    },
  ]

function UserEquipmentPage() {
  const {
    equipment,
    serverConnection,
  } = useSystem()

  /*
    Nombre d'équipements
    actuellement en ligne.
  */
  const onlineCount =
    equipment.filter(
      (item) =>
        item.status ===
        'ONLINE',
    ).length

  /*
    Nombre d'équipements
    actuellement activés.
  */
  const activeCount =
    equipment.filter(
      (item) =>
        item.enabled,
    ).length

  return (
    <div className="user-page">
      {/*
        ========================================================
        EN-TÊTE
        ========================================================
      */}
      <header className="page-heading">
        <div>
          <p className="page-eyebrow">
            Installation
          </p>

          <h1>
            Équipements
          </h1>

          <p>
            Activez ou désactivez chaque équipement
            et ouvrez sa fiche pour consulter
            son état détaillé.
          </p>
        </div>

        <span
          className={
            `page-status ${
              serverConnection.status ===
              'CONNECTED'
                ? 'is-success'
                : 'is-warning'
            }`
          }
        >
          <Cpu
            aria-hidden="true"
          />

          {onlineCount}
          {' / '}
          {equipment.length}
          {' '}
          en ligne
        </span>
      </header>

      {/*
        ========================================================
        RÉSUMÉ
        ========================================================
      */}
      <div className="equipment-summary-row">
        <article>
          <span>
            Équipements actifs
          </span>

          <strong>
            {activeCount}
            {' / '}
            {equipment.length}
          </strong>
        </article>

        <article>
          <span>
            Connexion
          </span>

          <strong>
            {serverConnection.status ===
            'CONNECTED'
              ? 'Opérationnelle'
              : 'Interrompue'}
          </strong>
        </article>
      </div>

      {/*
        ========================================================
        GROUPES D'ÉQUIPEMENTS
        ========================================================
      */}
      <div className="equipment-overview-grid">
        {equipmentGroups.map(
          (group) => {
            const Icon =
              group.icon

            /*
              On récupère les équipements
              présents dans ce groupe.

              flatMap permet d'éviter
              les problèmes TypeScript liés à undefined.
            */
            const groupEquipment =
              group.equipmentIds.flatMap(
                (equipmentId) => {
                  const item =
                    equipment.find(
                      (
                        equipmentItem,
                      ) =>
                        equipmentItem.id ===
                        equipmentId,
                    )

                  return item
                    ? [item]
                    : []
                },
              )

            /*
              Le groupe est considéré disponible
              si tous ses équipements sont en ligne.
            */
            const allOnline =
              groupEquipment.length >
                0 &&
              groupEquipment.every(
                (item) =>
                  item.status ===
                  'ONLINE',
              )

            return (
              <section
                className="equipment-group-card"
                key={
                  group.id
                }
              >
                {/*
                  ==================================================
                  TITRE DU GROUPE
                  ==================================================
                */}
                <div className="equipment-group-heading">
                  <span className="equipment-group-icon">
                    <Icon
                      aria-hidden="true"
                    />
                  </span>

                  <div>
                    <h2>
                      {group.title}
                    </h2>

                    <p>
                      {
                        group.description
                      }
                    </p>
                  </div>

                  <span
                    className={
                      `equipment-group-status ${
                        allOnline
                          ? 'is-online'
                          : 'is-offline'
                      }`
                    }
                  >
                    <i
                      className={
                        `status-dot ${
                          allOnline
                            ? 'is-online'
                            : 'is-offline'
                        }`
                      }
                    />

                    {allOnline
                      ? 'Disponible'
                      : 'À vérifier'}
                  </span>
                </div>

                {/*
                  ==================================================
                  ÉQUIPEMENTS DU GROUPE
                  ==================================================
                */}
                <div className="equipment-group-list">
                  {groupEquipment.map(
                    (item) => (
                      <EquipmentControl
                        key={
                          item.id
                        }
                        equipment={
                          item
                        }
                        detailsPath={
                          `/utilisateur/equipements/${item.id}`
                        }
                      />
                    ),
                  )}
                </div>
              </section>
            )
          },
        )}
      </div>
    </div>
  )
}

export default UserEquipmentPage