import {
  Bookmark,
  BookmarkCheck,
  Bot,
  Clock3,
  Film,
  Image,
} from 'lucide-react'

import { Link } from 'react-router-dom'

import CameraViewer
  from '../components/user/CameraViewer'

import { useSystem } from '../hooks/useSystem'

function UserCamerasPage() {
  const {
    media,
    toggleMediaSaved,
  } = useSystem()

  /*
    Cette page ne montre que les médias de la caméra fixe.
    Les médias du robot resteront associés au robot.
  */
  const fixedCameraMedia = media.filter(
    (item) =>
      item.cameraId === 'camera-salon',
  )

  return (
    <div className="user-page">
      <header className="page-heading">
        <div>
          <p className="page-eyebrow">
            Vidéo fixe
          </p>

          <h1>Caméra du salon</h1>

          <p>
            Le direct, l’alimentation de la caméra
            et ses enregistrements sont réunis ici.
          </p>
        </div>

        <Link
          className="secondary-button"
          to="/utilisateur/robot"
        >
          <Bot aria-hidden="true" />
          Ouvrir le robot caméra
        </Link>
      </header>

      <CameraViewer cameraId="camera-salon" />

      <section className="page-section">
        <div className="section-heading">
          <div>
            <p className="page-eyebrow">
              Conservation
            </p>

            <h2>Médias de cette caméra</h2>
          </div>

          <span className="section-note">
            <Clock3 aria-hidden="true" />
            Suppression automatique après 48 h
          </span>
        </div>

        <div className="media-grid">
          {fixedCameraMedia.map((item) => (
            <article
              className="media-card"
              key={item.id}
            >
              <div className="media-preview">
                {item.kind === 'VIDEO' ? (
                  <Film aria-hidden="true" />
                ) : (
                  <Image aria-hidden="true" />
                )}

                <span>
                  {item.kind === 'VIDEO'
                    ? 'Vidéo'
                    : 'Capture'}
                </span>
              </div>

              <div className="media-card-body">
                <div>
                  <strong>
                    {item.cameraName}
                  </strong>

                  <span>{item.createdAt}</span>
                </div>

                <p>
                  {item.saved
                    ? 'Conservation permanente demandée'
                    : `Expiration : ${item.expiresAt}`}
                </p>

                <button
                  className={
                    item.saved
                      ? 'saved-media-button'
                      : 'secondary-button'
                  }
                  type="button"
                  onClick={() =>
                    toggleMediaSaved(item.id)
                  }
                >
                  {item.saved ? (
                    <BookmarkCheck
                      aria-hidden="true"
                    />
                  ) : (
                    <Bookmark
                      aria-hidden="true"
                    />
                  )}

                  {item.saved
                    ? 'Sauvegardé'
                    : 'Sauvegarder'}
                </button>
              </div>
            </article>
          ))}

          {fixedCameraMedia.length === 0 && (
            <div className="empty-state">
              <Image aria-hidden="true" />

              <strong>
                Aucun média récent
              </strong>

              <span>
                Les captures et vidéos
                apparaîtront ici.
              </span>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}

export default UserCamerasPage