import {
  useEffect,
  useState,
} from 'react'

import {
  AlertTriangle,
  Camera,
  Clock3,
  Eye,
  MapPin,
  Radio,
  ShieldCheck,
  WifiOff,
} from 'lucide-react'

import {
  Link,
} from 'react-router-dom'

import {
  useSystem,
} from '../hooks/useSystem'

function UserAlertsPage() {
  const {
    activeAlert,
    equipment,
    serverConnection,
  } = useSystem()

  /*
    ============================================================
    CAMÉRA ASSOCIÉE À L'ALERTE
    ============================================================
  */

  const alertCamera =
    equipment.find(
      (item) =>
        item.id ===
        activeAlert.cameraId,
    )

  /*
    ============================================================
    FLUX ASSOCIÉ À LA BONNE CAMÉRA
    ============================================================
  */

  const alertStreamUrl =
    activeAlert.cameraId ===
    'camera-robot'
      ? import.meta.env
          .VITE_ROBOT_CAMERA_STREAM_URL
      : import.meta.env
          .VITE_FIXED_CAMERA_STREAM_URL

  /*
    ============================================================
    DISPONIBILITÉ DE LA CAMÉRA
    ============================================================
  */

  const cameraAvailable =
    serverConnection.status ===
      'CONNECTED' &&
    alertCamera?.status ===
      'ONLINE' &&
    alertCamera.enabled

  const [
    streamFailed,
    setStreamFailed,
  ] =
    useState(false)

  useEffect(
    () => {
      setStreamFailed(false)
    },
    [
      alertStreamUrl,
      alertCamera?.enabled,
      alertCamera?.status,
      serverConnection.status,
    ],
  )

  return (
    <div className="user-page">
      {/*
        ========================================================
        EN-TÊTE
        ========================================================
      */}

      <header className="page-heading">
        <div>
          <p className="page-eyebrow">
            Sécurité
          </p>

          <h1>
            Alertes
          </h1>

          <p>
            Consultez les événements détectés
            et le direct de la zone concernée.
          </p>
        </div>

        <span className="page-status is-warning">
          <AlertTriangle
            aria-hidden="true"
          />

          Alerte active
        </span>
      </header>

      <div className="alert-workspace">
        {/*
          ======================================================
          ALERTE
          ======================================================
        */}

        <section className="alert-detail-card">
          <div className="alert-notification-header">
            <div className="alert-detail-heading">
              <span>
                <AlertTriangle
                  aria-hidden="true"
                />
              </span>

              <div>
                <p>
                  Alerte
                  {' · '}
                  {activeAlert.id}
                </p>

                <h2>
                  {activeAlert.title}
                </h2>
              </div>
            </div>
          </div>

          <p className="alert-detail-description">
            {activeAlert.description}
          </p>

          {/*
            ====================================================
            DIRECT CAMÉRA
            ====================================================

            Aucun accord supplémentaire n'est demandé.

            Les profils possédant les droits d'accès
            peuvent consulter directement la caméra.
          */}

          <div className="alert-live-preview">
            <div className="alert-live-preview-screen">
              {cameraAvailable &&
              alertStreamUrl &&
              !streamFailed ? (
                <img
                  src={alertStreamUrl}
                  alt={
                    `Direct de ${
                      alertCamera?.name ??
                      'la caméra'
                    }`
                  }
                  onError={() => {
                    setStreamFailed(true)
                  }}
                />
              ) : (
                <div className="alert-live-placeholder">
                  {serverConnection.status ===
                  'DISCONNECTED' ? (
                    <WifiOff
                      aria-hidden="true"
                    />
                  ) : (
                    <Camera
                      aria-hidden="true"
                    />
                  )}

                  <strong>
                    {serverConnection.status ===
                    'DISCONNECTED'
                      ? 'Connexion interrompue'
                      : !cameraAvailable
                        ? 'Caméra indisponible'
                        : streamFailed
                          ? 'Flux vidéo inaccessible'
                          : 'Direct en attente'}
                  </strong>

                  <span>
                    {serverConnection.status ===
                    'DISCONNECTED'
                      ? 'Le direct sera rétabli dès que la communication avec le système sera disponible.'
                      : !cameraAvailable
                        ? "La caméra associée à cette alerte n'est pas disponible actuellement."
                        : streamFailed
                          ? 'Le flux vidéo ne peut pas être chargé actuellement.'
                          : 'Le direct apparaîtra ici dès que le flux sera disponible.'}
                  </span>
                </div>
              )}

              {cameraAvailable && (
                <span className="alert-live-badge">
                  <Radio
                    aria-hidden="true"
                  />

                  Direct
                </span>
              )}

              <span className="alert-live-location">
                {
                  alertCamera?.location ??
                  activeAlert.location
                }
              </span>
            </div>

            <div className="alert-live-preview-footer">
              <div>
                <span>
                  <Camera
                    aria-hidden="true"
                  />

                  Caméra associée
                </span>

                <strong>
                  {
                    alertCamera?.name ??
                    'Caméra de surveillance'
                  }
                </strong>
              </div>

              <Link
                className="alert-live-view-button"
                to="/utilisateur/cameras"
              >
                <Eye
                  aria-hidden="true"
                />

                Voir
              </Link>
            </div>
          </div>

          {/*
            ====================================================
            INFORMATIONS
            ====================================================
          */}

          <div className="alert-facts">
            <div>
              <MapPin
                aria-hidden="true"
              />

              <span>
                <small>
                  Zone concernée
                </small>

                <strong>
                  {activeAlert.location}
                </strong>
              </span>
            </div>

            <div>
              <Clock3
                aria-hidden="true"
              />

              <span>
                <small>
                  Détection
                </small>

                <strong>
                  {activeAlert.detectedAt}
                </strong>
              </span>
            </div>

            <div>
              <ShieldCheck
                aria-hidden="true"
              />

              <span>
                <small>
                  Indice de détection
                </small>

                <strong>
                  {activeAlert.confidence}
                  {' %'}
                </strong>
              </span>
            </div>
          </div>
        </section>

        {/*
          ======================================================
          SUIVI
          ======================================================
        */}

        <aside className="alert-side-card">
          <h2>
            Suivi de l'alerte
          </h2>

          <ol>
            <li className="is-complete">
              Mouvement détecté
            </li>

            <li className="is-complete">
              Alerte créée
            </li>

            <li className="is-current">
              Surveillance en cours
            </li>

            <li>
              Clôture de l'alerte
            </li>
          </ol>
        </aside>
      </div>
    </div>
  )
}

export default UserAlertsPage