import {
  Activity,
  BellRing,
  Camera,
  Cpu,
  LogOut,
  Power,
  RefreshCw,
  ShieldCheck,
  Wifi,
  WifiOff,
} from 'lucide-react'

import {
  useNavigate,
} from 'react-router-dom'

import NetworkIncidentModal from '../components/NetworkIncidentModal'

import {
  useAuth,
} from '../hooks/useAuth'

import {
  useSystem,
} from '../hooks/useSystem'

import '../styles/dashboard.css'
import '../styles/company-dashboard.css'

function CompanyDashboardPage() {
  const navigate =
    useNavigate()

  /*
    ============================================================
    AUTHENTIFICATION
    ============================================================
  */

  const {
    user,
    logout,
  } =
    useAuth()

  /*
    ============================================================
    ÉTAT GLOBAL
    ============================================================
  */

  const {
    equipment,
    activeAlert,
    activeDetectionSourceIds,
    serverConnection,
    feedback,
    isMockMode,
    toggleEquipment,
    simulateConnectionLoss,
    restoreConnection,
    clearFeedback,
  } =
    useSystem()

  /*
    ============================================================
    CAMÉRA FIXE
    ============================================================
  */

  const fixedCamera =
    equipment.find(
      (item) =>
        item.id ===
        'camera-salon',
    )

  /*
    ============================================================
    FLUX VIDÉO
    ============================================================
  */

  const fixedCameraStreamUrl =
    import.meta.env
      .VITE_FIXED_CAMERA_STREAM_URL

  /*
    ============================================================
    ACCÈS ENTREPRISE À LA CAMÉRA
    ============================================================

    Il n'y a plus de demande d'autorisation
    envoyée au particulier.

    L'accès dépend uniquement :

    - des droits du compte COMPANY,
      qui seront vérifiés plus tard par FastAPI ;
    - de la connexion au système ;
    - de l'état de la caméra ;
    - de son activation.

    React ne devra pas être la seule protection :
    FastAPI devra vérifier le rôle côté serveur.
  */

  const companyCanViewCamera =
    serverConnection.status ===
      'CONNECTED' &&
    fixedCamera?.status ===
      'ONLINE' &&
    fixedCamera?.enabled ===
      true

  /*
    ============================================================
    ÉQUIPEMENTS EN LIGNE
    ============================================================
  */

  const onlineEquipment =
    equipment.filter(
      (item) =>
        item.status ===
        'ONLINE',
    ).length

  /*
    ============================================================
    ALERTE ACTIVE
    ============================================================
  */

  const activeAlertCount =
    activeAlert.status ===
    'RESOLVED'
      ? 0
      : 1

  /*
    ============================================================
    DÉCONNEXION
    ============================================================
  */

  function handleLogout() {
    logout()

    navigate(
      '/connexion',
      {
        replace: true,
      },
    )
  }

  return (
    <main className="company-portal">
      {/*
        ========================================================
        BARRE SUPÉRIEURE
        ========================================================
      */}

      <header className="company-topbar">
        <div className="dashboard-brand">
          <span className="dashboard-logo">
            AM
          </span>

          <div>
            <strong>
              Atelier Maison
            </strong>

            <span>
              Centre de surveillance
            </span>
          </div>
        </div>

        <div className="company-topbar-actions">
          <span className="company-user-name">
            {user?.name}
          </span>

          <button
            type="button"
            onClick={
              handleLogout
            }
          >
            <LogOut
              aria-hidden="true"
            />

            Se déconnecter
          </button>
        </div>
      </header>

      {/*
        ========================================================
        CONTENU
        ========================================================
      */}

      <section className="company-content">
        {/*
          ======================================================
          TITRE + CONNEXION
          ======================================================
        */}

        <div className="company-heading-row">
          <div>
            <p className="dashboard-eyebrow">
              Supervision temps réel
            </p>

            <h1>
              Installation Maison principale
            </h1>

            <p>
              Toutes les commandes passent
              par le système central avant
              d'être transmises aux équipements
              de l'installation.
            </p>
          </div>

          <div
            className={
              `company-connection-pill ${
                serverConnection.status ===
                'CONNECTED'
                  ? 'is-online'
                  : 'is-offline'
              }`
            }
          >
            {serverConnection.status ===
            'CONNECTED' ? (
              <Wifi
                aria-hidden="true"
              />
            ) : (
              <WifiOff
                aria-hidden="true"
              />
            )}

            <span>
              <strong>
                {serverConnection.status ===
                'CONNECTED'
                  ? 'Système connecté'
                  : serverConnection.status ===
                      'CHECKING'
                    ? 'Connexion en cours'
                    : 'Système inaccessible'}
              </strong>

              <small>
                Dernier contact :
                {' '}
                {
                  serverConnection.lastContact
                }
              </small>
            </span>
          </div>
        </div>

        {/*
          ======================================================
          FEEDBACK
          ======================================================
        */}

        {feedback && (
          <div
            className="company-feedback"
            role="status"
          >
            <ShieldCheck
              aria-hidden="true"
            />

            <span>
              {feedback}
            </span>

            <button
              type="button"
              onClick={
                clearFeedback
              }
            >
              Fermer
            </button>
          </div>
        )}

        {/*
          ======================================================
          INDICATEURS
          ======================================================
        */}

        <div className="company-metrics">
          <article>
            <BellRing
              aria-hidden="true"
            />

            <span>
              Alertes actives
            </span>

            <strong>
              {
                activeAlertCount
              }
            </strong>
          </article>

          <article>
            <Cpu
              aria-hidden="true"
            />

            <span>
              Équipements en ligne
            </span>

            <strong>
              {onlineEquipment}
              {' / '}
              {equipment.length}
            </strong>
          </article>

          <article>
            <Activity
              aria-hidden="true"
            />

            <span>
              Sources utilisées
              par l'algorithme
            </span>

            <strong>
              {
                activeDetectionSourceIds.length
              }
            </strong>
          </article>
        </div>

        <div className="company-grid">
          {/*
            ====================================================
            ÉQUIPEMENTS
            ====================================================
          */}

          <section className="company-panel">
            <div className="company-panel-heading">
              <div>
                <p className="dashboard-eyebrow">
                  Contrôle distant
                </p>

                <h2>
                  Équipements
                </h2>
              </div>

              <span>
                Les changements sont appliqués
                automatiquement à la logique
                de détection.
              </span>
            </div>

            <div className="company-device-list">
              {equipment.map(
                (item) => {
                  const commandDisabled =
                    item.status ===
                      'OFFLINE' ||
                    !item.controllable ||
                    serverConnection.status !==
                      'CONNECTED'

                  return (
                    <article
                      className="company-device-row"
                      key={
                        item.id
                      }
                    >
                      <div>
                        <strong>
                          {
                            item.name
                          }
                        </strong>

                        <span>
                          {
                            item.location
                          }
                        </span>
                      </div>

                      <span
                        className={
                          `company-device-status ${
                            item.status ===
                            'ONLINE'
                              ? 'is-online'
                              : 'is-offline'
                          }`
                        }
                      >
                        {item.status ===
                        'ONLINE'
                          ? 'En ligne'
                          : 'Hors ligne'}
                      </span>

                      {item.controllable ? (
                        <button
                          className={
                            `company-device-toggle ${
                              item.enabled
                                ? 'is-enabled'
                                : ''
                            }`
                          }
                          type="button"
                          disabled={
                            commandDisabled
                          }
                          onClick={() =>
                            void toggleEquipment(
                              item.id,
                            )
                          }
                        >
                          <Power
                            aria-hidden="true"
                          />

                          {item.enabled
                            ? 'Désactiver'
                            : 'Activer'}
                        </button>
                      ) : (
                        <span className="company-readonly">
                          Lecture seule
                        </span>
                      )}
                    </article>
                  )
                },
              )}
            </div>
          </section>

          {/*
            ====================================================
            DIRECT VIDÉO
            ====================================================
          */}

          <section className="company-panel">
            <div className="company-panel-heading">
              <div>
                <p className="dashboard-eyebrow">
                  Direct vidéo
                </p>

                <h2>
                  Caméra du salon
                </h2>
              </div>
            </div>

            <div className="company-camera-screen">
              {companyCanViewCamera &&
              fixedCameraStreamUrl ? (
                <img
                  src={
                    fixedCameraStreamUrl
                  }
                  alt="Direct de la caméra du salon"
                />
              ) : (
                <div className="company-camera-placeholder">
                  {serverConnection.status ===
                  'DISCONNECTED' ? (
                    <WifiOff
                      aria-hidden="true"
                    />
                  ) : (
                    <Camera
                      aria-hidden="true"
                    />
                  )}

                  <strong>
                    {serverConnection.status ===
                    'DISCONNECTED'
                      ? 'Système inaccessible'
                      : fixedCamera?.status !==
                          'ONLINE'
                        ? 'Caméra hors ligne'
                        : !fixedCamera?.enabled
                          ? 'Caméra désactivée'
                          : 'Flux vidéo en attente'}
                  </strong>

                  <span>
                    {serverConnection.status ===
                    'DISCONNECTED'
                      ? 'Le direct sera rétabli lorsque la communication avec le système sera disponible.'
                      : fixedCamera?.status !==
                          'ONLINE'
                        ? "La caméra ne répond pas actuellement."
                        : !fixedCamera?.enabled
                          ? "Activez la caméra pour afficher le direct."
                          : "Ajoutez VITE_FIXED_CAMERA_STREAM_URL dans le fichier .env.local pour afficher le flux réel."}
                  </span>
                </div>
              )}
            </div>

            {/*
              ==================================================
              ALERTE ASSOCIÉE
              ==================================================
            */}

            <div className="company-alert-summary">
              <span>
                Alerte
                {' '}
                {
                  activeAlert.id
                }
              </span>

              <strong>
                {
                  activeAlert.title
                }
              </strong>

              <small>
                Zone :
                {' '}
                {
                  activeAlert.location
                }
                {' · '}
                Confiance :
                {' '}
                {
                  activeAlert.confidence
                }
                {' %'}
              </small>
            </div>
          </section>
        </div>

        {/*
          ======================================================
          TEST DE COUPURE
          ======================================================
        */}

        <section className="company-panel company-demo-panel">
          <div>
            <p className="dashboard-eyebrow">
              Test de résilience
            </p>

            <h2>
              Simulation de coupure réseau
            </h2>

            <p>
              Ce contrôle sert uniquement
              à démontrer le comportement prévu
              lorsque l'application ne peut plus
              joindre le système central.
            </p>
          </div>

          <div className="company-demo-actions">
            {isMockMode &&
            serverConnection.status ===
              'CONNECTED' && (
              <button
                className="company-danger-action"
                type="button"
                onClick={
                  simulateConnectionLoss
                }
              >
                <WifiOff
                  aria-hidden="true"
                />

                Simuler une coupure
              </button>
            )}

            {serverConnection.status ===
              'DISCONNECTED' && (
              <button
                className="company-primary-action"
                type="button"
                onClick={() =>
                  void restoreConnection()
                }
              >
                <RefreshCw
                  aria-hidden="true"
                />

                Rétablir / réessayer
              </button>
            )}
          </div>
        </section>
      </section>

      <NetworkIncidentModal />
    </main>
  )
}

export default CompanyDashboardPage