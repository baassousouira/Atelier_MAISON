import type {
  LucideIcon,
} from 'lucide-react'

import {
  ArrowLeft,
  Bot,
  Camera,
  CircleGauge,
  Clock3,
  Lightbulb,
  MapPin,
  Power,
  Radar,
  ShieldCheck,
  SunMedium,
  Video,
  Wifi,
  WifiOff,
} from 'lucide-react'

import {
  Link,
  useParams,
} from 'react-router-dom'

import {
  useSystem,
} from '../hooks/useSystem'

import type {
  EquipmentKind,
} from '../types/dashboard'

/*
  ============================================================
  ICÔNES PAR TYPE D'ÉQUIPEMENT
  ============================================================
*/
const equipmentIcons:
  Record<
    EquipmentKind,
    LucideIcon
  > = {
    CAMERA:
      Camera,

    ROBOT_CAMERA:
      Video,

    MOTION_SENSOR:
      Radar,

    LED:
      Lightbulb,

    PHOTORESISTOR:
      SunMedium,

    ROBOT:
      Bot,
  }

/*
  ============================================================
  LIBELLÉS
  ============================================================
*/
const kindLabels:
  Record<
    EquipmentKind,
    string
  > = {
    CAMERA:
      'Caméra de surveillance',

    ROBOT_CAMERA:
      'Caméra mobile',

    MOTION_SENSOR:
      'Capteur de mouvement',

    LED:
      "Signal d'alerte",

    PHOTORESISTOR:
      'Capteur de luminosité',

    ROBOT:
      'Robot mobile',
  }

/*
  ============================================================
  DESCRIPTION DE CHAQUE ÉQUIPEMENT
  ============================================================
*/
const kindDescriptions:
  Record<
    EquipmentKind,
    string
  > = {
    CAMERA:
      'Permet de surveiller le salon en vidéo et de réaliser des captures lorsque la caméra est activée.',

    ROBOT_CAMERA:
      'Fournit le retour vidéo utilisé lors du pilotage du robot mobile.',

    MOTION_SENSOR:
      'Détecte les mouvements dans la zone de l’entrée et transmet ses détections à la logique de surveillance lorsqu’il est activé.',

    LED:
      "Produit un signal lumineux local lorsque le système ou une règle d'alerte demande son activation.",

    /*
      CORRECTION :

      La photorésistance est associée
      à la CAMÉRA FIXE.
    */
    PHOTORESISTOR:
      'Mesure la luminosité de la zone de la caméra fixe afin que le système puisse adapter automatiquement les règles de surveillance qui utilisent cette information.',

    ROBOT:
      'Permet de déplacer le module mobile de surveillance à distance.',
  }

/*
  ============================================================
  SOURCES UTILISABLES PAR LA SURVEILLANCE
  ============================================================
*/
const detectionKinds:
  EquipmentKind[] = [
    'CAMERA',
    'ROBOT_CAMERA',
    'MOTION_SENSOR',
    'PHOTORESISTOR',
  ]

function UserEquipmentDetailPage() {
  /*
    Récupération de l'identifiant
    contenu dans l'URL.

    Exemple :

    /utilisateur/equipements/light-sensor
  */
  const {
    equipmentId,
  } = useParams()

  const {
    equipment,

    toggleEquipment,

    activeDetectionSourceIds,

    serverConnection,
  } = useSystem()

  /*
    Recherche de l'équipement.
  */
  const item =
    equipment.find(
      (
        equipmentItem,
      ) =>
        equipmentItem.id ===
        equipmentId,
    )

  /*
    ============================================================
    ÉQUIPEMENT INCONNU
    ============================================================
  */
  if (!item) {
    return (
      <div className="user-page">
        <Link
          className="equipment-back-link"
          to="/utilisateur/equipements"
        >
          <ArrowLeft
            aria-hidden="true"
          />

          Retour aux équipements
        </Link>

        <section className="equipment-not-found">
          <strong>
            Équipement introuvable
          </strong>

          <span>
            Cet équipement n'existe pas
            ou n'est plus associé
            à cette installation.
          </span>
        </section>
      </div>
    )
  }

  /*
    Icône.
  */
  const Icon =
    equipmentIcons[
      item.kind
    ]

  /*
    ============================================================
    CONTRÔLE
    ============================================================

    Une commande est possible uniquement si :

    - l'équipement est contrôlable ;
    - il est en ligne ;
    - le système central répond.
  */
  const canControl =
    item.controllable &&
    item.status ===
      'ONLINE' &&
    serverConnection.status ===
      'CONNECTED'

  /*
    Cet équipement peut-il fournir
    des données utilisées par la surveillance ?
  */
  const participatesInDetection =
    detectionKinds.includes(
      item.kind,
    )

  /*
    Est-il actuellement utilisé
    par la logique de surveillance ?
  */
  const currentlyUsedByDetection =
    activeDetectionSourceIds.includes(
      item.id,
    )

  /*
    ============================================================
    INTERFACE DÉDIÉE
    ============================================================

    Caméra fixe :
      page Caméra

    Capteur luminosité :
      lié à la caméra fixe,
      donc accès possible à la page Caméra.

    Robot / caméra mobile :
      page Robot.
  */
  let dedicatedPage:
    string | null = null

  let dedicatedPageLabel:
    string | null = null

  if (
    item.kind ===
    'CAMERA'
  ) {
    dedicatedPage =
      '/utilisateur/cameras'

    dedicatedPageLabel =
      'Ouvrir la caméra'
  }

  if (
    item.kind ===
    'PHOTORESISTOR'
  ) {
    dedicatedPage =
      '/utilisateur/cameras'

    dedicatedPageLabel =
      'Voir la caméra associée'
  }

  if (
    item.kind ===
      'ROBOT_CAMERA' ||
    item.kind ===
      'ROBOT'
  ) {
    dedicatedPage =
      '/utilisateur/robot'

    dedicatedPageLabel =
      'Ouvrir le pilotage'
  }

  return (
    <div className="user-page">
      {/*
        ========================================================
        RETOUR
        ========================================================
      */}
      <Link
        className="equipment-back-link"
        to="/utilisateur/equipements"
      >
        <ArrowLeft
          aria-hidden="true"
        />

        Retour aux équipements
      </Link>

      {/*
        ========================================================
        EN-TÊTE
        ========================================================
      */}
      <header className="equipment-detail-hero">
        <span className="equipment-detail-icon">
          <Icon
            aria-hidden="true"
          />
        </span>

        <div>
          <p className="page-eyebrow">
            {
              kindLabels[
                item.kind
              ]
            }
          </p>

          <h1>
            {item.name}
          </h1>

          <p>
            {
              kindDescriptions[
                item.kind
              ]
            }
          </p>
        </div>

        {/*
          Activation / désactivation.
        */}
        <button
          className={
            `equipment-main-toggle ${
              item.enabled
                ? 'is-enabled'
                : ''
            }`
          }
          type="button"
          disabled={
            !canControl
          }
          onClick={() => {
            void toggleEquipment(
              item.id,
            )
          }}
        >
          <Power
            aria-hidden="true"
          />

          {item.enabled
            ? 'Désactiver'
            : 'Activer'}
        </button>
      </header>

      {/*
        ========================================================
        CONNEXION INTERROMPUE
        ========================================================
      */}
      {serverConnection.status !==
        'CONNECTED' && (
        <div className="equipment-detail-warning">
          <WifiOff
            aria-hidden="true"
          />

          <span>
            Les commandes sont indisponibles
            tant que la connexion avec
            le système n'est pas rétablie.
          </span>
        </div>
      )}

      <div className="equipment-detail-grid">
        {/*
          ======================================================
          ÉTAT
          ======================================================
        */}
        <section className="equipment-detail-card">
          <div className="equipment-detail-card-heading">
            <h2>
              État
            </h2>
          </div>

          <div className="equipment-detail-state">
            <div>
              {item.status ===
              'ONLINE' ? (
                <Wifi
                  aria-hidden="true"
                />
              ) : (
                <WifiOff
                  aria-hidden="true"
                />
              )}

              <span>
                <small>
                  Connexion
                </small>

                <strong>
                  {item.status ===
                  'ONLINE'
                    ? 'En ligne'
                    : 'Hors ligne'}
                </strong>
              </span>
            </div>

            <div>
              <Power
                aria-hidden="true"
              />

              <span>
                <small>
                  Fonctionnement
                </small>

                <strong>
                  {item.enabled
                    ? 'Actif'
                    : 'Désactivé'}
                </strong>
              </span>
            </div>
          </div>
        </section>

        {/*
          ======================================================
          INFORMATIONS
          ======================================================
        */}
        <section className="equipment-detail-card">
          <div className="equipment-detail-card-heading">
            <h2>
              Informations
            </h2>
          </div>

          <div className="equipment-detail-info-list">
            <div>
              <MapPin
                aria-hidden="true"
              />

              <span>
                <small>
                  Emplacement
                </small>

                <strong>
                  {
                    item.location
                  }
                </strong>
              </span>
            </div>

            <div>
              <Clock3
                aria-hidden="true"
              />

              <span>
                <small>
                  Dernier contact
                </small>

                <strong>
                  {
                    item.lastSeen
                  }
                </strong>
              </span>
            </div>

            {item.value && (
              <div>
                <CircleGauge
                  aria-hidden="true"
                />

                <span>
                  <small>
                    Mesure actuelle
                  </small>

                  <strong>
                    {
                      item.value
                    }
                  </strong>
                </span>
              </div>
            )}
          </div>
        </section>

        {/*
          ======================================================
          UTILISATION PAR LA SURVEILLANCE
          ======================================================
        */}
        {participatesInDetection && (
          <section className="equipment-detail-card equipment-detail-detection-card">
            <div className="equipment-detail-card-heading">
              <h2>
                Utilisation par la surveillance
              </h2>
            </div>

            <div className="detection-state-row">
              <ShieldCheck
                aria-hidden="true"
              />

              <div>
                <strong>
                  {currentlyUsedByDetection
                    ? 'Pris en compte'
                    : 'Ignoré actuellement'}
                </strong>

                <span>
                  {currentlyUsedByDetection
                    ? "Cet équipement est actif et disponible. Ses données peuvent donc être utilisées automatiquement par la logique de surveillance."

                    : "Cet équipement n'est actuellement pas utilisé par la logique de surveillance."}
                </span>
              </div>
            </div>
          </section>
        )}

        {/*
          ======================================================
          INFORMATION SPÉCIFIQUE PHOTORÉSISTANCE
          ======================================================

          On indique clairement
          qu'elle est associée à la caméra fixe.
        */}
        {item.kind ===
          'PHOTORESISTOR' && (
          <section className="equipment-detail-card equipment-detail-detection-card">
            <div className="equipment-detail-card-heading">
              <h2>
                Équipement associé
              </h2>
            </div>

            <div className="detection-state-row">
              <Camera
                aria-hidden="true"
              />

              <div>
                <strong>
                  Caméra fixe du salon
                </strong>

                <span>
                  Ce capteur mesure la luminosité
                  de la zone surveillée par
                  la caméra fixe. Il n'est pas
                  associé au robot mobile.
                </span>
              </div>
            </div>
          </section>
        )}

        {/*
          ======================================================
          CONTRÔLE AVANCÉ
          ======================================================
        */}
        {dedicatedPage &&
          dedicatedPageLabel && (
          <section className="equipment-detail-card equipment-detail-action-card">
            <div>
              <h2>
                Contrôle avancé
              </h2>

              <p>
                Accédez à l'écran associé
                pour utiliser les fonctions
                complémentaires.
              </p>
            </div>

            <Link
              className="primary-button"
              to={
                dedicatedPage
              }
            >
              {
                dedicatedPageLabel
              }
            </Link>
          </section>
        )}
      </div>
    </div>
  )
}

export default UserEquipmentDetailPage